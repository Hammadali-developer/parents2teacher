
        <!-- Footer Area Start -->
        <footer class="main-footer bg-blue text-white pt-75">
            <div class="container">
                <div class="row justify-content-between">
                    <div class="col-lg-6 col-sm-12 col-12">
                        <div class="footer-widget about-widget">
                            <div class="footer-logo">
                                <a href="index.html"> <img src="assets/images/main_images/footer_logo.png"
                                        alt="Logo"></a>
                            </div>

                            <p class="pt-4 pb-0">Faucibus quis fringilla scelerisque dui.
                                Amet parturient dui venenatis amet sagittis
                                viverra vel tincidunt. Orci tincidunt.</p>


                            <div class="social-style-one">
                                <!-- <a href="contact.html"><i class="fab fa-facebook-f"></i></a>
                                <a href="contact.html"><i class="fab fa-twitter"></i></a>
                                <a href="contact.html"><i class="fab fa-linkedin-in"></i></a>
                                <a href="contact.html"><i class="fab fa-youtube"></i></a> -->
                            </div>
                            <div class="live-btn">
                                <button class="btn btn-primary chat-btn">
                                    <i class="fa fa-comment" aria-hidden="true"></i>Start Live Chat
                                </button>
                            </div>


                        </div>
                    </div>
                    <div class="col-lg-2 col-md-12 col-sm-4 col-6">
                        <div class="footer-widget menu-widget">
                            <h5 class="footer-heading">Company</h5>
                            <ul>
                                 <li><a href="index.php">Home</a></li>
                                <li><a href="about.php">About Us</a></li>
                                <li><a href="courses.php">Courses</a></li>
                                <li><a href="instructor.php">Instructors</a></li>
                                <li><a href="event.php">Events</a></li>
                                <li><a href="contact.php">Contact Us</a></li>
                                
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-3 col-sm-4 col-6">
                        <div class="footer-widget menu-widget">
                            <h5 class="footer-heading">Resources</h5>
                            <ul class="unorderd_list">
                                <li><a href="#">Community</a></li>
                                <li><a href="#">Support</a></li>
                                <li><a href="#">Video Guides</a></li>
                                <li><a href="#">Documentation</a></li>
                                <li><a href="#">Security</a></li>
                                <li><a href="#">Template</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-3 col-sm-4">
                        <div class="footer-widget menu-widget">
                            <h5 class="footer-heading">Help</h5>
                            <ul class="unorderd_list">
                                <li><a href="#">Customer Support</a></li>
                                <li><a href="#">Terms & Conditions</a></li>
                                <li><a href="#">Privacy Policy</a></li>
                            </ul>
                        </div>
                    </div>

                </div>
            </div>
            <div class="copyright-area bg-dark-blue rel">
                <div class="container">
                    <div class="row">
                        <div class="col-12">
                            <div class="copyright-inner">
                                <p>Copyright © 2024 Parents 2 Teachers Live</p>
                                <p><a href="https://octawebdesign.com/">Designed by Octa Web Designs</a></p>
                               
                            </div>
                        </div>
                    </div>
                   
                </div>
                <!-- Scroll Top Button -->
                <button class="scroll-top scroll-to-target" data-target="html"><span
                        class="fas fa-angle-double-up"></span>

                </button>
            </div>
        </footer>
        <!-- Footer Area End -->

    </div>
    <!--End pagewrapper-->
  

  <!-- AOS LINKING -->
     <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script>
      AOS.init();
    </script>
    <!--====== Jquery ======-->
    <script src="assets/js/jquery-3.6.0.min.js"></script>
    <!--====== Bootstrap ======-->
    <script src="assets/js/bootstrap.min.js"></script>
    <!--====== Appear Js ======-->
    <script src="assets/js/appear.min.js"></script>
    <!--====== Slick ======-->
    <script src="assets/js/slick.min.js"></script>
    <!--====== jQuery UI ======-->
    <script src="assets/js/jquery-ui.min.js"></script>
    <!--====== Isotope ======-->
    <script src="assets/js/isotope.pkgd.min.js"></script>
    <!--====== Circle Progress bar ======-->
    <script src="assets/js/circle-progress.min.js"></script>
    <!--====== Images Loader ======-->
    <script src="assets/js/imagesloaded.pkgd.min.js"></script>
    <!--====== Nice Select ======-->
    <script src="assets/js/jquery.nice-select.min.js"></script>
    <!--====== Magnific Popup ======-->
    <script src="assets/js/jquery.magnific-popup.min.js"></script>
    <!--  WOW Animation -->
    <script src="assets/js/wow.min.js"></script>
    <!-- Custom script -->
    <script src="assets/js/script.js"></script>
    <script>
        $('.mobile-slide').slick({
            dots: true,
            infinite: false,
            speed: 300,
            slidesToShow: 1,
            slidesToScroll: 1,
            mobileFirst: true,
            responsive: [
                {
                    breakpoint: 1300,
                    settings: "unslick"

                },

                {
                    breakpoint: 1024,
                    settings: {
                        slidesToShow: 3,
                        slidesToScroll: 3,
                        settings: "unslick",
                        infinite: true,
                        dots: true
                    }
                },
                {
                    breakpoint: 600,
                    settings: {
                        slidesToShow: 2,
                        slidesToScroll: 2
                    }
                },
                {
                    breakpoint: 575,
                    settings: {
                        slidesToShow: 1,
                        slidesToScroll: 1
                    }
                },
                {
                    breakpoint: 480,
                    settings: {
                        slidesToShow: 1,
                        slidesToScroll: 1
                    }
                }
                // You can unslick at a given breakpoint now by adding:
                // settings: "unslick"
                // instead of a settings object
            ]
        });
    </script>

</body>

</html>