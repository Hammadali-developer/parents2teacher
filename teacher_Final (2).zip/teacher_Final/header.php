<!DOCTYPE html>
<html lang="zxx">

<head>
    <!--====== Required meta tags ======-->
    <meta charset="utf-8" />
    <meta name="description" content="" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!--====== Title ======-->
    <title>Parents To Teachers || Home</title>
    <!--====== Favicon Icon ======-->
    <link rel="shortcut icon" href="assets/images/favicon.png" type="image/x-icon">
    <!--====== Google Fonts ======-->
    <link
        href="https://fonts.googleapis.com/css2?family=Mulish:wght@400;500;600;700&family=Oswald:wght@300;400;500;600;700&display=swap"
        rel="stylesheet">
    <link
        href="https://fonts.googleapis.com/css2?family=DM+Sans:ital,opsz,wght@0,9..40,100..1000;1,9..40,100..1000&display=swap"
        rel="stylesheet">
    <!--====== Flaticon ======-->
    <link rel="stylesheet" href="assets/css/flaticon.min.css">
    <!--====== Font Awesome ======-->
    <link rel="stylesheet" href="assets/css/font-awesome-5.9.0.min.css">
     <!-- FONT AWEOME CDN -->
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css"
        integrity="sha512-1ycn6IcaQQ40/MKBW2W4Rhis/DbILU74C1vSrLJxCq57o941Ym01SwNsOMqvEBFlcgUa6xLiPY/NS5R+E6ztJQ=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />

    <!-- AOS LINKING -->
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
   <!-- BOOTSTRAP ICON CDN -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    
  
    <!--====== Bootstrap ======-->
    <link rel="stylesheet" href="assets/css/bootstrap-4.5.3.min.css">
    <!--====== Magnific Popup ======-->
    <link rel="stylesheet" href="assets/css/magnific-popup.min.css">
    <!--====== Nice Select ======-->
    <link rel="stylesheet" href="assets/css/nice-select.min.css">
    <!--====== jQuery UI ======-->
    <link rel="stylesheet" href="assets/css/jquery-ui.min.css">
    <!--====== Animate ======-->
    <link rel="stylesheet" href="assets/css/animate.min.css">
    <!--====== Slick ======-->
    <link rel="stylesheet" href="assets/css/slick.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick-theme.css" />
    <!--====== Main Style ======-->
    <link rel="stylesheet" href="assets/css/style.css">

</head>

<body class="home-one">
    <div class="page-wrapper">

        <!-- Preloader -->
        <div class="preloader"></div>

        <!-- main header -->
        <header class="main-header">
            
            <div class="container-fluid topbar">
                <div class="topbar_para  d-flex   justify-content-center ">
                    <p class="pt-3">New Members: Get your first 7 days of Parents2Teachers Live Premium for free! Click
                        here to redeem</p>
                    <ul class="topbar-icon pt-2">
                        <li><a href="#"><i class="fa fa-arrow-right" aria-hidden="true"></i></i></a></li>
                    </ul>
                </div>
            </div>
            <!-- Header-Upper -->
            <div class="header-upper">
                <div class="container-fluid clearfix">
                    <div class="header-inner d-flex align-items-center justify-content-between">
                        <div class="logo-outer d-lg-flex align-items-center">
                            <div class="logo"><a href="index.php"><img src="assets/images/main_images/Logo.png"
                                        alt="Logo" title="Logo"></a></div>
                       
                        </div>

                        <div class="nav-outer clearfix">
                            <!-- Main Menu -->
                            <nav class="main-menu navbar-expand-lg">
                                <div class="navbar-header">
                                    <div class="mobile-logo bg-green br-10 p-15">
                                        <a href="index.php">
                                            <img src="assets/images/main_images/Logo.png" alt="Logo" title="Logo">
                                        </a>
                                    </div>

                                    <!-- Toggle Button -->
                                    <button type="button" class="navbar-toggle" data-toggle="collapse"
                                        data-target=".navbar-collapse">
                                        <span class="icon-bar"></span>
                                        <span class="icon-bar"></span>
                                        <span class="icon-bar"></span>
                                    </button>
                                </div>

                                <div class="navbar-collapse collapse clearfix">
                                    <ul class="navigation clearfix">
                                     
                                        <li class="current"><a href="index.php">home</a></li>
                                        <li><a href="about.php">About Us</a></li>
                                        <li><a href="courses.php">Courses</a></li>
                                        <li><a href="instructor.php">Instructors</a></li>
                                        <li><a href="event.php">Events</a></li>
                                        <li><a href="contact.php">contact us</a></li>
                                        <li class="login"><a href="#">Login</a></li>
                                        <li class="sign"><a href="signup.php">Sign Up</a></li>
                                      
                                      
                                    </ul>
                                </div>

                            </nav>
                            <!-- Main Menu End-->
                        </div>

                        <!-- Menu Button -->
                        <div class="menu_btn d-flex align-items-center mob-hide">
                    
                            <button class="login_up">
                                <i class="fa fa-globe" aria-hidden="true"></i>
                                <a href="#">Login</a>
                             </button>
                            <button class="btn btn-primary  taxt-black sign_up">
                                <a href="signup.php">Sign up</a>
                             </button>
                        </div>
                    </div>
                </div>
            </div>
            <!--End Header Upper-->
        </header>
