<?php include 'header.php';?>


        <!--Form Back Drop-->
        <div class="form-back-drop"></div>

   


        <!-- Hero Section Start -->
        <section class="hero-section rel z-1 pt-150 rpt-135 pb-75 rpb-100">
            <div class="container">
                <span class="sub-title style-two mb-20 wow fadeInUp delay-0-2s text-center">Education & Online
                    Courses</span>
                <div class="row align-items-center pt-4">
                    <div class="col-lg-3 col-md-12 col-12">
                        <div class="hero-content">
                            <div class="hero-right-images text-lg-right wow fadeInUp delay-0-2s">
                                <img src="assets/images/main_images/women_two.png" class="women_image img-fluid"
                                    alt="Hero">
                                <h4 class="wow fadeInUp delay-0-6s heading-one">How it Works </h4>
                                <h6 class="wow fadeInUp delay-0-6s two-mints heading-two">2 mins</h6>
                            </div>

                            <div class="star pt-4">
                                <img src="assets/images/main_images/Star.png" class="star img-fluid" alt="star">
                                <p class="wow fadeInUp delay-0-6s  star_para pt-4">This course was comprehensive and
                                    covered
                                    everything i needed to know about calculus
                                </p>
                                <div class="star_logo d-flex ">
                                    <img src="assets/images/main_images/roger.png" class="star img-fluid" alt="star">
                                    <div class="">
                                        <h5 class="wow fadeInUp delay-0-6s  star_heading">Roger Rester </h5>
                                        <p class="wow fadeInUp delay-0-6s  star_para">Home Schooling Parent </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-7 col-md-12 col-12">
                        <div class="hero-content rpt-25 rmb-75">

                            <h1 class="mb-20 wow fadeInUp delay-0-4s text-center big_heading">Learn Without Limits With
                                Parents2Teachers</h1>
                            <p class="wow fadeInUp delay-0-6s text-center ps-4 para">Start, switch, or advance your
                                career
                                with more than 5,400 courses, Elevate your learning with our Professional, Certified,
                                and Verified Consultants from world-class universities and companies.</p>
                            <!-- <div class="hero-btn mt-30 wow fadeInUp delay-0-8s">
                                <a href="course-grid.html" class="theme-btn">Get Your Free Coach <i
                                        class="fas fa-arrow-right"></i></a>
                            </div> -->
                            <div class="hero-btns d-flex justify-content-center mt-4">
                                <button class="btn btn-primary hero-btn-1">
                                    <a href="#"> Join Now</a>
                                </button>
                                <button class="btn btn-primary hero-btn-2">
                                    <a href="#">Lear More</a>
                                </button>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-2 pt-4 vertical-align-bottom">
                        <div class="hero-right-images text-lg-right wow fadeInUp delay-0-2s">
                            <img src="assets/images/main_images/Image Box 2.png" class="women_image_two img-fluid"
                                alt="Hero">
                            <h4 class="wow fadeInUp delay-0-6s heading-three">How it Works </h4>
                            <h6 class="wow fadeInUp delay-0-6s two-mints heading-four">2 mins</h6>
                        </div>
                    </div>
                </div>
            </div>
            <span class="bg-text">coach</span>
        </section>
        <!-- Hero Section End -->


        <!-- Features Section Start -->
        <section class="features-section rel z-1 pt-80 pb-40 bg-blue counter text-white">
            <div class="container">
                <div class="row  mobile-slide justify-content-center ">

                    <div class="col-lg-3 col-md-6 col-12">
                        <div class="feature-item wow fadeInUp delay-0-2s ">
                            <!-- <div class="image">
                                <img src="assets/images/features/icon1.png" alt="Icon">
                            </div> -->
                            <div class="content">
                                <h4 class="text-white">34K +</h4>
                                <p>Success Stories </p>
                            </div>
                            <div class="bordr"></div>
                        </div>

                    </div>
                    <div class="col-lg-3 col-md-6 col-12">
                        <div class="feature-item wow fadeInUp delay-0-4s">
                            <!-- <div class="image">
                                <img src="assets/images/features/icon2.png" alt="Icon">
                            </div> -->
                            <div class="content">
                                <h4 class="text-white">210 +</h4>
                                <p>Expert Instructor </p>
                            </div>
                            <div class="bordr"></div>

                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 col-12">
                        <div class="feature-item wow fadeInUp delay-0-6s">
                            <!-- <div class="image">
                                <img src="assets/images/features/icon1.png" alt="Icon">
                            </div> -->
                            <div class="content">
                                <h4 class="text-white">54K +</h4>
                                <p>Online Courses </p>
                            </div>
                            <div class="bordr"></div>

                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 col-12">
                        <div class="feature-item wow fadeInUp delay-0-6s">
                            <!-- <div class="image">
                                <img src="assets/images/features/icon1.png" alt="Icon">
                            </div> -->
                            <div class="content">
                                <h4 class="text-white">80K +</h4>
                                <p>Worldwide Members</p>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
            <!-- <img class="rectangle-dots" src="assets/images/shapes/rectangle-dots.png" alt="Shape">
            <img class="circle-dots" src="assets/images/shapes/circle-dots.png" alt="Shape"> -->
        </section>
        <!-- Features Section End -->


        <!-- About Section Start -->
        <section class="about-section pt-130 rpt-100">
            <div class="container">
                <div class="row">
                    <div class="col-lg-7 align-self-end">
                        <div class="about-content rel z-2 pb-115 rpb-85 wow fadeInRight delay-0-2s">
                            <div class="section-title mb-40">
                                <span class="mb-25 ">WHO We ARE</span>
                                <h2 class="pt-2">Your Online Learning Partner</h2>
                                <p class="pt-2">Egestas faucibus nisl et ultricies. Tempus lectus condimentum tristique
                                    mauris id
                                    vitae. Id pulvinar a eget vitae pellentesque ridiculus platea. Vulputate cursus.</p>
                            </div>
                            <!-- <div class="about-features">
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="feature-item">
                                            <div class="icon">
                                                <i class="fas fa-check"></i>
                                            </div>
                                            <div class="content">
                                                <h5>Exclusive Coach</h5>
                                                <p>Sit consectetur adipiscing eiuse tempor incides</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="feature-item">
                                            <div class="icon">
                                                <i class="fas fa-check"></i>
                                            </div>
                                            <div class="content">
                                                <h5>Creative Minds</h5>
                                                <p>Sit consectetur adipiscing eiuse tempor incides</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="feature-item">
                                            <div class="icon">
                                                <i class="fas fa-check"></i>
                                            </div>
                                            <div class="content">
                                                <h5>Master Certified</h5>
                                                <p>Sit consectetur adipiscing eiuse tempor incides</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="feature-item">
                                            <div class="icon">
                                                <i class="fas fa-check"></i>
                                            </div>
                                            <div class="content">
                                                <h5>Video Tutorials</h5>
                                                <p>Sit consectetur adipiscing eiuse tempor incides</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div> -->
                            <!-- <div class="about-btns">
                                <a href="about.html" class="theme-btn style-two my-15">Learn more us <i
                                        class="fas fa-arrow-right"></i></a>
                                <a href="faqs.html" class="read-more">How it works <i
                                        class="fas fa-arrow-right"></i></a>
                            </div> -->
                        </div>
                    </div>
                    <div class="col-lg-5">
                        <!-- <div class="about-man rmb-75 wow fadeInLeft delay-0-2s">
                            <img src="assets/images/about/man.png" alt="Man">
                        </div> -->
                        <div class="video">
                            <div class="d-flex justify-content-between">
                                <h4>Video Course</h4>
                                <h5>(1/110)</h5>
                            </div>
                            <div class="video_bg d-flex justify-content-between align-items-center mt-2">
                                <img src="assets/images/main_images/Play Icon.png" alt="play">
                                <h5 class="text-start"> Introduction</h5>
                                <h6 class="hundreds"> 700</h6>
                            </div>
                            <br>
                            <div class="video_bg-seond d-flex justify-content-between align-items-center">
                                <img src="assets/images/main_images/Lock Icon.png" alt="play">
                                <h5 class="text-start"> Guide to creating courses</h5>
                                <h6 class="hundreds"> 700</h6>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- About Section End -->
        <!-- course start -->
        <section class="course">
            <div class="container">
                <div class="row mobile-slide">
                    <div class="col-lg-4 col-md-6 col-12">
                        <div class="cards">
                            <img src="assets/images/main_images/Icon.png" class="card-img-top" alt="book">

                            <h5 class="">Online Courses</h5>
                            <p class="">Egestas faucibus nisl et ultricies. Tempus lectus condimentum tristique mauris
                                id vitae. Id pulvinar eget vitae.
                            </p>

                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-12">
                        <div class="cards">
                            <img src="assets/images/main_images/Icon (1).png" class="card-img-top" alt="book">

                            <h5 class="">Upgrade Skills</h5>
                            <p class="">Egestas faucibus nisl et ultricies. Tempus lectus condimentum tristique mauris
                                id vitae. Id pulvinar eget vitae.
                            </p>

                        </div>
                    </div>

                    <div class="col-lg-4 col-md-6 col-12">
                        <div class="cards">
                            <img src="assets/images/main_images//Icon (2).png" class="card-img-top" alt="book">

                            <h5 class="">Certified Consultants</h5>
                            <p class="">Egestas faucibus nisl et ultricies. Tempus lectus condimentum tristique mauris
                                id vitae. Id pulvinar eget vitae.
                            </p>
                        </div>
                    </div>
                </div>
            </div>

        </section>
        <!-- course end -->


        <!-- Coach Section Start -->
        <section class="coach-section rel z-1 pt-120 rpt-90 pb-100 rpb-70 bg-lighter">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-xl-6 col-lg-7 col-md-8">
                        <div class="section-title text-center mb-40">
                            <h6 class="best_popular_heading"> Featured Courses</h6>
                            <h2 class="best_popular_heading_two">Browse Our Popular Courses</h2>
                            <p class="best_popular_para">Egestas faucibus nisl et ultricies. Tempus lectus
                                condimentum tristique mauris id vitae. Id pulvinar a eget vitae pellentesque ridiculus
                                platea. Vulputate cursus.</p>
                        </div>
                    </div>
                </div>
                <!-- <ul class="coach-filter mb-35">
                    <li data-filter="*" class="current">Show All</li>
                    <li data-filter=".design">Web Design</li>
                    <li data-filter=".marketing">Marketing</li>
                    <li data-filter=".development">Development</li>
                    <li data-filter=".technology">IT & Technology</li>
                    <li data-filter=".photography">Photography</li>
                </ul> -->
                <div class="row  coach-active justify-content-center">
                    <div class="col-lg-4 col-md-6 item marketing technology mt-4 mb-4">
                        <div class="coach-bg">
                            <div class="coach-item wow fadeInUp delay-0-2s ">
                                <div class="coach-image">
                                    <!-- <a href="#" class="category">Lifestyle</a> -->
                                    <img src="assets/images/main_images/coach1.png" alt="Coach">
                                </div>
                                <div class="coach-content">
                                    <span class="label">Mathematics</span>
                                    <h4><a href="#">Guide to Advanced Calculations and Multiplications</a></h4>
                                    <div class="ratting-price">
                                        <div class="ratting">
                                            <!-- <i class="fas fa-star"></i> -->
                                            <i class="fa fa-mobile" aria-hidden="true"></i>
                                            <span>3 Lessons</span>
                                        </div>
                                        <i class="fa fa-clock" aria-hidden="true"></i><span>2 hr 40 mins</span>

                                    </div>
                                    <ul class="coach-footer">
                                        <li><img src="assets/images/main_images/blog1.png" alt="Coach"><span style="padding-left: 9px; font-family: Manrope, sans-serif;font-weight: 700;
                                    font-size: 18px;">Anthony Wade</span> </li>
                                        <li>
                                            <span class="price">60.00</span>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 item design photography mt-4 mb-4">
                        <div class="coach-bg">
                            <div class="coach-item wow fadeInUp delay-0-4s">
                                <div class="coach-image">
                                    <!-- <a href="#" class="category">Lifestyle</a> -->
                                    <img src="assets/images/main_images/coach2.png" alt="Coach">
                                </div>
                                <div class="coach-content">
                                    <span class="label">Mathematics</span>
                                    <h4><a href="#">Guide to Advanced Calculations and Multiplications</a></h4>
                                    <div class="ratting-price">
                                        <div class="ratting">
                                            <!-- <i class="fas fa-star"></i> -->
                                            <i class="fa fa-mobile" aria-hidden="true"></i>
                                            <span>3 Lessons</span>
                                        </div>

                                        <i class="fa fa-clock" aria-hidden="true"></i><span>2 hr 40 mins</span>
                                    </div>
                                    <ul class="coach-footer">
                                        <li><img src="assets/images/main_images/blog3.png" alt="Coach"><span style="padding-left: 9px; font-family: Manrope, sans-serif;font-weight: 700;
                                    font-size: 18px;">Anthony Wade</span> </li>

                                        <li>
                                            <span class="price">60.00</span>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 item development photography mt-4 mb-4">
                        <div class="coach-bg">
                            <div class="coach-item wow fadeInUp delay-0-6s">
                                <div class="coach-image">
                                    <!-- <a href="#" class="category">Lifestyle</a> -->
                                    <img src="assets/images/main_images/coach3.png" alt="Coach">
                                </div>
                                <div class="coach-content">
                                    <span class="label">Mathematics</span>
                                    <h4><a href="#">Guide to Advanced Calculations and Multiplications</a></h4>
                                    <div class="ratting-price">
                                        <div class="ratting">
                                            <!-- <i class="fas fa-star"></i> -->
                                            <i class="fa fa-mobile" aria-hidden="true"></i>
                                            <span>3 Lessons</span>
                                        </div>
                                        <i class="fa fa-clock" aria-hidden="true"></i><span>2 hr 40 mins</span>
                                    </div>
                                    <ul class="coach-footer">
                                        <li><img src="assets/images/main_images/blog4.png" alt="Coach"><span style="padding-left: 9px; font-family: Manrope, sans-serif;font-weight: 700;
                                    font-size: 18px;">Anthony Wade</span> </li>
                                        <li>
                                            <span class="price">60.00</span>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-4 col-md-6 item design technology mt-4 mb-4">
                        <div class="coach-bg">
                            <div class="coach-item wow fadeInUp delay-0-2s">
                                <div class="coach-image">
                                    <!-- <a href="#" class="category">Lifestyle</a> -->
                                    <img src="assets/images/main_images/coach4.png" alt="Coach">
                                </div>
                                <div class="coach-content">
                                    <span class="label">Mathematics</span>
                                    <h4><a href="#">Guide to Advanced Calculations and Multiplications</a></h4>
                                    <div class="ratting-price">
                                        <div class="ratting">
                                            <!-- <i class="fas fa-star"></i> -->
                                            <i class="fa fa-mobile" aria-hidden="true"></i>
                                            <span>3 Lessons</span>
                                        </div>
                                        <i class="fa fa-clock" aria-hidden="true"></i><span>2 hr 40 mins</span>
                                    </div>
                                    <ul class="coach-footer">
                                        <li><img src="assets/images/main_images/blog5.png" alt="Coach"><span style="padding-left: 9px; font-family: Manrope, sans-serif;font-weight: 700;
                                    font-size: 18px;">Anthony Wade</span> </li>
                                        <li>
                                            <span class="price">60.00</span>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 item development photography mt-4 mb-4">
                        <div class="coach-bg">
                            <div class="coach-item wow fadeInUp delay-0-4s">
                                <div class="coach-image">
                                    <!-- <a href="#" class="category">Lifestyle</a> -->
                                    <img src="assets/images/main_images/coach5.png" alt="Coach">
                                </div>
                                <div class="coach-content">
                                    <span class="label">Mathematics</span>
                                    <h4><a href="#">Guide to Advanced Calculations and Multiplications</a></h4>
                                    <div class="ratting-price">
                                        <div class="ratting">
                                            <!-- <i class="fas fa-star"></i> -->
                                            <i class="fa fa-mobile" aria-hidden="true"></i>
                                            <span>3 Lessons</span>
                                        </div>

                                        <i class="fa fa-clock" aria-hidden="true"></i><span>2 hr 40 mins</span>
                                    </div>
                                    <ul class="coach-footer">
                                        <li><img src="assets/images/main_images/blog2.png" alt="Coach"><span style="padding-left: 9px; font-family: Manrope, sans-serif;font-weight: 700;
                                    font-size: 18px;">Anthony Wade</span></li>
                                        <li>
                                            <span class="price">60.00</span>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 item design technology mt-4 mb-4">
                        <div class="coach-bg">
                            <div class="coach-item wow fadeInUp delay-0-6s">
                                <div class="coach-image">
                                    <!-- <a href="#" class="category">Lifestyle</a> -->
                                    <img src="assets/images/main_images/coach6.png" alt="Coach">
                                </div>
                                <div class="coach-content">
                                    <span class="label">Mathematics</span>
                                    <h4><a href="#">Guide to Advanced Calculations and Multiplications</a></h4>
                                    <div class="ratting-price">
                                        <div class="ratting">
                                            <!-- <i class="fas fa-star"></i> -->
                                            <i class="fa fa-mobile" aria-hidden="true"></i>
                                            <span>3 Lessons</span>
                                        </div>
                                        <i class="fa fa-clock" aria-hidden="true"></i><span>2 hr 40 mins</span>

                                    </div>
                                    <ul class="coach-footer">
                                        <li><img src="assets/images/main_images/blog6.png" alt="Coach"><span style="padding-left: 9px; font-family: Manrope, sans-serif;font-weight: 700;
                                    font-size: 18px;">Anthony Wade</span></li>
                                        <li>
                                            <span class="price">60.00</span>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <button class="btn btn-primary coach-btn d-flex justify-content-center">
                    <a href="#"> Explore All Courses</a>
                </button>
            </div>
        </section>
        <!-- Coach Section End -->
        <!-- Men Section Start -->
        <section class="about-section pt-120  rpt-100">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6 col-md-12 col-12">
                        <div class="men_image">
                            <div class="men_img">
                                <img src="assets/images/main_images/men_laptop.png" alt="men">

                            </div>
                            <div class="men_star d-flex  mt-2">
                                <img src="assets/images/main_images/yelloIcon.png" alt="play">
                                <h5 class="text-start"> Learn at your own pace, with lifetime access on mobile and
                                    desktop.</h5>
                            </div>
                            <div class="d-flex  mt-2">
                                <!-- <img src="assets/images/main_images/yelloIcon.png" alt="play">
                                <h5 class="text-start"> Learn at your own pace, with lifetime access on mobile and desktop.</h5> -->
                                <!-- <button>Download</button> -->
                                <ul class="men_unorder">
                                    <li><a href="#">Download Now</a> </li>
                                </ul>
                            </div>
                            <br>


                        </div>
                    </div>
                    <div class="col-lg-6 col-md-12 col-12">
                        <!-- <div class="about-man rmb-75 wow fadeInLeft delay-0-2s">
                            <img src="assets/images/about/man.png" alt="Man">
                        </div> -->
                        <div class="men-content rel z-2 pb-115 rpb-85 wow fadeInRight delay-0-2s">
                            <div class="section-title mb-40">
                                <h6> <span class="mb-25">Why Choose Us</span></h6>
                                <h2 class="pt-2">Your Learning Journey, Your Way</h2>
                                <p class="para pt-2">Nibh consectetur morbi fusce aliquet scelerisque. Quis dis orci
                                    eleifend
                                    vel at sed et. Laoreet tristique ut fringilla augue vitae. Turpis volutpat morbi
                                    risus imperdiet viverra odio. Fringilla sit ut mattis.
                                </p>
                            </div>
                            <div class="men_icon d-flex">
                                <div class="men_icon_img">
                                    <img src="assets/images/main_images/Frame 6.png" alt="men">
                                </div>
                                <div class=" men_icon_text">
                                    <h5 class="pt-2">High-Quality Content Course</h2>
                                        <p class="para pt-2">Enim amet enim volutpat luctus ipsum pellentesque massa
                                            nisl
                                            sed. Sit ut nibh odio morbi diam. Mi euismod diam.
                                        </p>
                                </div>
                            </div>
                            <div class="men_icon d-flex">
                                <div class="men_icon_img">
                                    <img src="assets/images/main_images/Frame 6.png" alt="men">
                                </div>
                                <div class=" men_icon_text">
                                    <h5 class="pt-2">Interactive Learning Experience</h2>
                                        <p class="para pt-2">Enim amet enim volutpat luctus ipsum pellentesque massa
                                            nisl
                                            sed. Sit ut nibh odio morbi diam. Mi euismod diam.
                                        </p>
                                </div>
                            </div>
                            <div class="men_icon d-flex">
                                <div class="men_icon_img">
                                    <img src="assets/images/main_images/Frame 6.png" alt="men">
                                </div>
                                <div class=" men_icon_text">
                                    <h5 class="pt-2">Exceptional Support</h2>
                                        <p class="para pt-2">Enim amet enim volutpat luctus ipsum pellentesque massa
                                            nisl
                                            sed. Sit ut nibh odio morbi diam. Mi euismod diam.
                                        </p>
                                </div>
                            </div>

                        </div>

                    </div>
                </div>
            </div>
        </section>
        <!-- Men Section End -->


        <!-- Work Process Section Start -->
        <!-- <section class="work-process-section bg-white rel z-1 pt-130 rpt-100 pb-100 rpb-70">
            <div class="container">
                <div class="row justify-content-between align-items-center pb-30 wow fadeInUp delay-0-2s">
                    <div class="col-xl-7 col-lg-8">
                        <div class="section-title">
                            <span class="sub-title mb-15">How It Works</span>
                            <h2>Very Simple Steps to Success Golas</h2>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="slider-arrow-btns text-lg-right mt-10">
                            <button class="work-prev"><i class="fas fa-angle-left"></i></button>
                            <button class="work-next"><i class="fas fa-angle-right"></i></button>
                        </div>
                    </div>
                </div>
                <div class="work-step-wrap wow fadeInUp delay-0-4s">
                    <div class="work-step-item">
                        <span class="number">01</span>
                        <div class="content">
                            <h4>Transformation Completed</h4>
                            <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium</p>
                        </div>
                    </div>
                    <div class="work-step-item">
                        <span class="number">02</span>
                        <div class="content">
                            <h4>Schedule a Meeting</h4>
                            <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium</p>
                        </div>
                    </div>
                    <div class="work-step-item">
                        <span class="number">03</span>
                        <div class="content">
                            <h4>Make a Decision</h4>
                            <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium</p>
                        </div>
                    </div>
                </div>
            </div>
        </section> -->
        <!-- Work Process Section End -->


        <!-- Newsletter Section Start -->
        <!-- <section class="newsletter-section pb-130 rpb-100 wow fadeInUp delay-0-2s">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-6">
                        <div class="newsletter-video overlay">
                            <img src="assets/images/video/video-bg.jpg" alt="Video">
                            <a href="https://www.youtube.com/watch?v=9Y7ma241N8k" class="mfp-iframe video-play"><i
                                    class="fas fa-play"></i></a>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="newsletter-content bg-lighter">
                            <div class="section-title mb-20">
                                <span class="sub-title mb-25">Newsletters</span>
                                <h2>Get Our Every Single Notifications</h2>
                            </div>
                            <p>Sit amet consectetur adipiscinelit eiusmod tempor incididunt ut labore et dolore magna
                                aliqua suspendisse ultrices gravida. commodo viverra maecenas accumsan facilisis.</p>
                            <form class="newsletter-form mt-25" action="#">
                                <div class="newsletter-radios mb-25">
                                    <div class="custom-control custom-radio">
                                        <input type="radio" class="custom-control-input" id="hero-wekly" name="example1"
                                            checked>
                                        <label class="custom-control-label" for="hero-wekly">Regular Updates</label>
                                    </div>
                                    <div class="custom-control custom-radio">
                                        <input type="radio" class="custom-control-input" id="hero-monthly"
                                            name="example1">
                                        <label class="custom-control-label" for="hero-monthly">Weekly Updates</label>
                                    </div>
                                </div>
                                <div class="newsletter-email">
                                    <label for="email"><i class="far fa-envelope"></i></label>
                                    <input id="email" type="email" placeholder="Enter Email Address" required>
                                    <button type="submit" class="theme-btn">Subscribe <i
                                            class="fas fa-arrow-right"></i></button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section> -->
        <!-- Newsletter Section End -->


        <!-- Events Section Start -->
        <section class="events-section rel z-1 py-130 rpy-100 bg-blue">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-xl-7 col-lg-8 col-md-9">
                        <div class="section-title text-center mb-55">
                            <!-- <span class="sub-title mb-25">Events & Program</span>
                            <h2>We’reArranged Yearly Cultural Events & Program</h2> -->
                            <h6 class="best_popular_heading"> Featured Courses</h6>
                            <h2 class="best_popular_heading_two">Browse Our Popular Courses</h2>
                            <p class="best_popular_para">Egestas faucibus nisl et ultricies. Tempus lectus
                                condimentum tristique mauris id vitae. Id pulvinar a eget vitae pellentesque ridiculus
                                platea. Vulputate cursus.</p>
                        </div>
                    </div>
                </div>
                <div class="event-wrap">
                    <div class="event-item wow fadeInUp delay-0-2s">
                        <div class="image">
                            <img src="assets/images/main_images/blog1.png" alt="Event">
                            <span class="date"><i class="fa fa-thumbs-up" aria-hidden="true"></i>92% Positive
                                Feedback</span>
                        </div>
                        <div class="event-content">
                            <h6>Expert in Digital Marketing</h6>
                            <h4>Anthony Wade<span><img src="assets/images/main_images/greenIcon.png" alt="Event"></span>
                            </h4>
                            <span class="location"><i class="fas fa-clock"></i> 24+ h taught</span>
                            <span class="video-camera"><i class="fas fa-video"></i> video chat</span>
                        </div>
                    </div>
                    <div class="event-item wow fadeInUp delay-0-4s">
                        <div class="image">
                            <img src="assets/images/main_images/blog3.png" alt="Event">
                            <span class="date"><i class="fa fa-thumbs-up" aria-hidden="true"></i>92% Positive
                                Feedback</span>
                        </div>
                        <div class="event-content">
                            <h6>Expert in Digital Marketing</h6>
                            <h4>Betty Calhoun</h4>
                            <span class="location"><i class="fas fa-clock"></i> 24+ h taught</span>
                            <span class="video-camera"><i class="fas fa-video"></i> video chat</span>
                        </div>
                    </div>
                    <div class="event-item wow fadeInUp delay-0-6s">
                        <div class="image">
                            <img src="assets/images/main_images/blog4.png" alt="Event">
                            <span class="date"><i class="fa fa-thumbs-up" aria-hidden="true"></i>92% Positive
                                Feedback</span>
                        </div>
                        <div class="event-content">
                            <h6>Expert in Digital Marketing</h6>
                            <h4>David Aplegate</h4>
                            <span class="location"><i class="fas fa-clock"></i> 24+ h taught</span>
                            <span class="video-camera"><i class="fas fa-video"></i> video chat</span>
                        </div>
                    </div>
                    <div class="event-item wow fadeInUp delay-0-2s">
                        <div class="image">
                            <img src="assets/images/main_images/blog2.png" alt="Event">
                            <span class="date"><i class="fa fa-thumbs-up" aria-hidden="true"></i>92% Positive
                                Feedback</span>
                        </div>
                        <div class="event-content">
                            <h6>Expert in Digital Marketing</h6>
                            <h4>Karen Barnes</h4>
                            <span class="location"><i class="fas fa-clock"></i> 24+ h taught</span>
                            <span class="video-camera"><i class="fas fa-video"></i> video chat</span>
                        </div>
                    </div>
                    <!-- <div class="event-item wow fadeInUp delay-0-4s">
                        <div class="image">
                            <img src="assets/images/main_images/blog1.png" alt="Event">
                            <span class="date">25 march 2022</span>
                        </div>
                        <div class="event-content">
                            <h4>How Much Needs Life Coach For Human Beings</h4>
                            <span class="location"><i class="fas fa-map-marker-alt"></i> 55 Main Street, New York</span>
                        </div>
                    </div>
                    <div class="event-item wow fadeInUp delay-0-6s">
                        <div class="image">
                            <img src="assets/images/main_images/blog2.png" alt="Event">
                            <span class="date">25 march 2022</span>
                        </div>
                        <div class="event-content">
                            <h4>How Much Needs Life Coach For Human Beings</h4>
                            <span class="location"><i class="fas fa-map-marker-alt"></i> 55 Main Street, New York</span>
                        </div>
                    </div> -->
                </div>
            </div>
            <span class="bg-text">coach</span>
            <img class="rectangle-dots" src="assets/images/shapes/rectangle-dots.png" alt="Shape">
            <img class="circle-dots" src="assets/images/shapes/circle-dots.png" alt="Shape">
            <button class="btn btn-primary coach-btn d-flex justify-content-center">
                
                <a href="#"> Become Instructors</a>
            </button>
        </section>
        <!-- Events Section End -->


        <!-- step section -->
        <section class="step_section">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <p class="heading-sec1 text-start">HOW IT WORKS</p>
                        <p class="sec4-head1 fs-1">YOUR ONLINE LEARNING JOURNEY, MADE EASY</p>
                        <p class="sec9-text1">Lorem ipsum dolor sit amet consectetur adipisicing elit. Illum minus
                            consequatur
                            repellat? Numquam,
                            eligendi! Facere magni exercitationem cumque nemo dolore!</p>
                    </div>



                    <div class="col-lg-4">
                        <div class="d-flex abc ">
                            <div class="sec9-num px-2 rounded-circle">
                                <img src="assets/images/main_images/Number.png" alt="number">
                            </div>
                            <div class="line21"></div>
                        </div>
                        <h5 class="mt-5 fs-3">Choose Your Course</h5>
                        <p class="sec9-text1">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Asperiores,
                            eligendi!</p>


                    </div>

                    <div class="col-lg-4">
                        <div class="d-flex abc">
                            <div class="sec9-num px-2 rounded-circle">
                                <img src="assets/images/main_images/Number (2).png" alt="number">

                            </div>
                            <div class="line21"></div>
                        </div>
                        <h5 class="mt-5 fs-3">Sign Up and Pay</h5>
                        <p class="sec9-text1">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Asperiores,
                            eligendi!</p>

                    </div>

                    <div class="col-lg-4">
                        <div class="d-flex abc">
                            <div class="sec9-num px-2 rounded-circle">

                                <img src="assets/images/main_images/Number (3).png" alt="number">

                            </div>
                            <div class="line21"></div>
                        </div>
                        <h5 class="mt-5 fs-3">Learn and Engage</h5>
                        <p class="sec9-text1">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Asperiores,
                            eligendi!</p>

                    </div>
                </div>
            </div>
        </section>
        <!-- step section end -->


        <!-- Blog Section Start -->
        <section class="blog-section">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-xl-12 col-lg-12 col-md-12">
                        <div class="section-title text-center mb-55">
                            <span class="blog_sub_heading  mb-20">PRICING & PLANS</span>
                            <h2 class="blog_heading">Get Started For As Low As $30/mo</h2>
                            <p class="blog_para">Egestas faucibus nisl et ultricies. Tempus lectus
                                condimentum tristique mauris id vitae. Id pulvinar a eget vitae pellentesque ridiculus
                                platea. Vulputate cursus.</p>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-4 col-md-6 col-12">
                        <!-- <div class="blog-item big-item wow fadeInUp delay-0-2s">
                    <div class="blog-image">
                        <img src="assets/images/blog/blog1.jpg" alt="Blog">
                    </div>
                    <div class="blog-content">
                        <span class="date"><span>25</span> March</span>
                        <div class="content">
                            <h4><a href="blog-details.html">Building Web Layouts For Dual-Screen And Foldable
                                    Devices Designing</a></h4>
                            <ul class="blog-meta">
                                <li><i class="far fa-user"></i> <a href="blog.html">By Somalia</a></li>
                                <li><i class="far fa-comments"></i> <a href="blog.html">Comments (5)</a></li>
                            </ul>
                        </div>
                    </div>
                </div> -->
                        <div class="blog-item wow fadeInUp delay-0-6s">
                            <div class="blog-content">
                                <!-- <span class="date"><span>03</span> April</span> -->
                                <div class="blog_content">
                                    <div class="d-flex align-items-center justify-content-between">
                                        <h3>Base Plan</h3>
                                        <h4>$30.00 / mo</h4>
                                    </div>
                                    <span class="inculded">What’s Inculded?</span>

                                    <ul class="blog_unorderd">
                                        <li>Lorem ipsum dolor sit amet, consec.</li>
                                        <li>Lorem ipsum dolor sit amet, consec.</li>
                                        <li>Lorem ipsum dolor sit amet, consec.</li>
                                        <li>Lorem ipsum dolor sit amet, consec.</li>
                                        <li>Lorem ipsum dolor sit amet, consec.</li>
                                        <li>Lorem ipsum dolor sit amet, consec.</li>
                                        <li>Lorem ipsum dolor sit amet, consec.</li>
                                        <li>Lorem ipsum dolor sit amet, consec.</li>
                                        <li>Lorem ipsum dolor sit amet, consec.</li>
                                        <li>Lorem ipsum dolor sit amet, consec.</li>

                                    </ul>
                                    <a href="#" class="blog_btn">Sign Up As Base Member</a>
                                    <!-- <ul class="blog-meta">
                                <li><i class="far fa-user"></i> <a href="blog.html">By Somalia</a></li>
                                <li><i class="far fa-comments"></i> <a href="blog.html">Com (5)</a></li>
                            </ul> -->
                                    <!-- <h5><a href="blog-details.html">Useful VS Code Esions Front-End Develop</a></h5>
                            <p>Sit amet consectetur adiscins eiusmod tempor incididunt</p>
                            <a href="blog-details.html" class="read-more">Read more <i
                                    class="fas fa-arrow-right"></i>
                                </a> -->
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-12">
                        <div class="blog-item wow fadeInUp delay-0-6s">
                            <!-- <div class="blog-image">
                        <img src="assets/images/blog/blog3.jpg" alt="Blog">
                    </div> -->
                            <div class="blog-content">
                                <div class="blog_content">
                                    <div class="d-flex align-items-center justify-content-between">
                                        <h3>Base Plan</h3>
                                        <h4>$30.00 / mo</h4>
                                    </div>
                                    <span class="inculded">What’s Inculded?</span>

                                    <ul class="blog_unorderd">
                                        <li>Lorem ipsum dolor sit amet, consec.</li>
                                        <li>Lorem ipsum dolor sit amet, consec.</li>
                                        <li>Lorem ipsum dolor sit amet, consec.</li>
                                        <li>Lorem ipsum dolor sit amet, consec.</li>
                                        <li>Lorem ipsum dolor sit amet, consec.</li>
                                        <li>Lorem ipsum dolor sit amet, consec.</li>
                                        <li>Lorem ipsum dolor sit amet, consec.</li>
                                        <li>Lorem ipsum dolor sit amet, consec.</li>
                                        <li>Lorem ipsum dolor sit amet, consec.</li>
                                        <li>Lorem ipsum dolor sit amet, consec.</li>

                                    </ul>
                                    <a href="#" class="blog_btn">Sign Up As Base Member</a>
                                    <!-- <span class="date"><span>03</span> April</span>
                        <div class="content">
                            <ul class="blog-meta">
                                <li><i class="far fa-user"></i> <a href="blog.html">By Somalia</a></li>
                                <li><i class="far fa-comments"></i> <a href="blog.html">Com (5)</a></li>
                            </ul>
                            <h5><a href="blog-details.html">Useful VS Code Esions Front-End Develop</a></h5>
                            <p>Sit amet consectetur adiscins eiusmod tempor incididunt</p>
                            <a href="blog-details.html" class="read-more">Read more <i
                                    class="fas fa-arrow-right"></i></a>
                        </div> -->
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-12">

                        <div class="blog-item wow fadeInUp delay-0-6s">
                            <!-- <div class="blog-image">
                        <img src="assets/images/blog/blog3.jpg" alt="Blog">
                    </div> -->
                            <div class="blog-content">
                                <div class="blog_content">
                                    <div class="d-flex align-items-center justify-content-between">
                                        <h3>Base Plan</h3>
                                        <h4>$30.00 / mo</h4>
                                    </div>
                                    <span class="inculded">What’s Inculded?</span>

                                    <ul class="blog_unorderd">
                                        <li>Lorem ipsum dolor sit amet, consec.</li>
                                        <li>Lorem ipsum dolor sit amet, consec.</li>
                                        <li>Lorem ipsum dolor sit amet, consec.</li>
                                        <li>Lorem ipsum dolor sit amet, consec.</li>
                                        <li>Lorem ipsum dolor sit amet, consec.</li>
                                        <li>Lorem ipsum dolor sit amet, consec.</li>
                                        <li>Lorem ipsum dolor sit amet, consec.</li>
                                        <li>Lorem ipsum dolor sit amet, consec.</li>
                                        <li>Lorem ipsum dolor sit amet, consec.</li>
                                        <li>Lorem ipsum dolor sit amet, consec.</li>

                                    </ul>
                                    <a href="#" class="blog_btn">Sign Up As Base Member</a>
                                    <!-- <span class="date"><span>03</span> April</span>
                        <div class="content">
                            <ul class="blog-meta">
                                <li><i class="far fa-user"></i> <a href="blog.html">By Somalia</a></li>
                                <li><i class="far fa-comments"></i> <a href="blog.html">Com (5)</a></li>
                            </ul>
                            <h5><a href="blog-details.html">Useful VS Code Esions Front-End Develop</a></h5>
                            <p>Sit amet consectetur adiscins eiusmod tempor incididunt</p>
                            <a href="blog-details.html" class="read-more">Read more <i
                                    class="fas fa-arrow-right"></i></a>
                        </div> -->
                                </div>
                            </div>
                        </div>

                        <!-- <div class="col-xl-4 col-md-6 col-12">
                <div class="blog-item wow fadeInUp delay-0-6s">
                    <div class="blog-image">
                        <img src="assets/images/blog/blog3.jpg" alt="Blog">
                    </div>
                    <div class="blog-content">
                        <div class="blog_content">
                            <div class="d-flex align-items-center justify-content-between">
                                <h3>Base Plan</h3>
                                <h4>$30.00 / mo</h4>
                            </div>
                            <span class="inculded">What’s Inculded?</span>
                                
                            <ul class="blog_unorderd">
                                <li>Lorem ipsum dolor sit amet, consec.</li>
                                <li>Lorem ipsum dolor sit amet, consec.</li>
                                <li>Lorem ipsum dolor sit amet, consec.</li>
                                <li>Lorem ipsum dolor sit amet, consec.</li>
                                <li>Lorem ipsum dolor sit amet, consec.</li>
                                <li>Lorem ipsum dolor sit amet, consec.</li>
                                <li>Lorem ipsum dolor sit amet, consec.</li>
                                <li>Lorem ipsum dolor sit amet, consec.</li>
                                <li>Lorem ipsum dolor sit amet, consec.</li>
                                <li>Lorem ipsum dolor sit amet, consec.</li>
                                
                            </ul>
                            <a href="#" class="blog_btn">Sign Up As Base Member</a> 
                    </div>
                </div>
            </div> -->
                    </div>
                    <!-- <div class="col-lg-4 col-md-6 col-12">
            <div class="blog-item wow fadeInUp delay-0-6s">
                <div class="blog-image">
                    <img src="assets/images/blog/blog3.jpg" alt="Blog">
                </div>
                <div class="blog-content">
                    <div class="blog_content">
                        <div class="d-flex align-items-center justify-content-between">
                            <h3>Base Plan</h3>
                            <h4>$30.00 / mo</h4>
                        </div>
                        <span class="inculded">What’s Inculded?</span>
                            
                        <ul class="blog_unorderd">
                            <li>Lorem ipsum dolor sit amet, consec.</li>
                            <li>Lorem ipsum dolor sit amet, consec.</li>
                            <li>Lorem ipsum dolor sit amet, consec.</li>
                            <li>Lorem ipsum dolor sit amet, consec.</li>
                            <li>Lorem ipsum dolor sit amet, consec.</li>
                            <li>Lorem ipsum dolor sit amet, consec.</li>
                            <li>Lorem ipsum dolor sit amet, consec.</li>
                            <li>Lorem ipsum dolor sit amet, consec.</li>
                            <li>Lorem ipsum dolor sit amet, consec.</li>
                            <li>Lorem ipsum dolor sit amet, consec.</li>
                            
                        </ul>
                        <a href="#" class="blog_btn">Sign Up As Base Member</a> 
                    <span class="date"><span>03</span> April</span>
                    <div class="content">
                        <ul class="blog-meta">
                            <li><i class="far fa-user"></i> <a href="blog.html">By Somalia</a></li>
                            <li><i class="far fa-comments"></i> <a href="blog.html">Com (5)</a></li>
                        </ul>
                        <h5><a href="blog-details.html">Useful VS Code Esions Front-End Develop</a></h5>
                        <p>Sit amet consectetur adiscins eiusmod tempor incididunt</p>
                        <a href="blog-details.html" class="read-more">Read more <i
                                class="fas fa-arrow-right"></i></a>
                    </div>
                </div>
            </div>
        </div> -->
                    <button class="btn btn-primary coach-btn d-flex justify-content-center">
                        
                        <a href="#"> Explore All Packages</a>
                    </button>
                    <!-- <div class="blog-more-btn pt-30 text-center">
                <a href="#" class="theme-btn style-three">view more news <i class="fas fa-arrow-right"></i></a>
            </div> -->
                </div>
            </div>
        </section>
        <!-- Blog Section End -->

      
        <!-- Testimonials Section Start -->
        <section class="testimonials-section rel z-1 py-100 rpy-100">

            <div class="container">
                <div class="row align-items-center justify-content-between">
                    <div class="col-lg-12 col-md-12 col-12">
                        <div class="testimonial-left-content rmb-65 wow fadeInLeft delay-0-2s">
                            <div class="testimonial-heading section-title">
                                <h6>REVIEWS & TESTIMONIALS</h6>
                                <h2>How Our Members See Us</h2>
                            </div>


                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-12">
                        <!-- Testimonial Carousel -->
                        <div class="testimonial-reel">
                            <!-- Testimonial -->

                            <div class="box">
                                <!-- Testimonial Image -->
                                <div class="ratting">
                                    <img src="assets/images/main_images/Star.png" alt="star">

                                    <!-- <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i> -->
                                </div>
                                <div class="designation">
                                    <h4>Seamless Collaboration</h4>
                                </div>
                                <p class="paraone">
                                    Parents 2 Teachers E-Learning Platform offers an intuitive interface and diverse
                                    resources for parents and teachers. Its communication tools ensure effective
                                    collaboration, enhancing children's learning experiences.
                                </p>
                                <div class="testi_author_img d-flex">
                                    <img src="assets/images/main_images/roger.png" alt="Author">
                                    <div class="author_section">
                                        <h4> Roger Rester</h4>
                                        <p class="para">Home Schooling Parent</p>
                                    </div>
                                </div>

                                <!-- / Testimonial Image -->

                            </div>


                            <!-- / Testimonial -->

                            <!-- Testimonial -->


                            <div class="box">
                                <!-- Testimonial Image -->
                                <div class="ratting">
                                    <img src="assets/images/main_images/Star.png" alt="star">

                                    <!-- <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i> -->
                                </div>
                                <div class="designation">
                                    <h4>Seamless Collaboration</h4>
                                </div>
                                <p class="paraone">
                                    Parents 2 Teachers E-Learning Platform offers an intuitive interface and diverse
                                    resources for parents and teachers. Its communication tools ensure effective
                                    collaboration, enhancing children's learning experiences.
                                </p>

                                <div class="testi_author_img d-flex">
                                    <img src="assets/images/main_images/roger.png" alt="Author">
                                    <div class="author_section">
                                        <h4> Roger Rester</h4>
                                        <p class="para">Home Schooling Parent</p>
                                    </div>
                                </div>
                                <!-- / Testimonial Image -->

                            </div>


                            <!-- / Testimonial -->

                            <!-- Testimonial -->


                            <div class="box">
                                <!-- Testimonial Image -->
                                <div class="ratting">
                                    <img src="assets/images/main_images/Star.png" alt="star">

                                    <!-- <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i> -->
                                </div>
                                <div class="designation">
                                    <h4>Seamless Collaboration</h4>
                                </div>
                                <p class="paraone">
                                    Parents 2 Teachers E-Learning Platform offers an intuitive interface and diverse
                                    resources for parents and teachers. Its communication tools ensure effective
                                    collaboration, enhancing children's learning experiences.
                                </p>
                                <!-- <figure class="image"> -->
                                <!-- <img class="img-fluid rounded-circle"
                                            src="assets/images/main_images/roger.png"> -->

                                <!-- </figure> -->
                                <div class="testi_author_img d-flex">
                                    <img src="assets/images/main_images/roger.png" alt="Author">
                                    <div class="author_section">
                                        <h4> Roger Rester</h4>
                                        <p class="para">Home Schooling Parent</p>
                                    </div>
                                </div>
                                <!-- / Testimonial Image -->

                            </div>


                            <!-- / Testimonial -->

                            <!-- Testimonial -->
                            <div class="box">
                                <!-- Testimonial Image -->
                                <div class="ratting">
                                    <img src="assets/images/main_images/Star.png" alt="star">

                                    <!-- <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i> -->
                                </div>
                                <div class="designation">
                                    <h4>Seamless Collaboration</h4>
                                </div>
                                <p class="paraone">
                                    Parents 2 Teachers E-Learning Platform offers an intuitive interface and diverse
                                    resources for parents and teachers. Its communication tools ensure effective
                                    collaboration, enhancing children's learning experiences.
                                </p>

                                <div class="testi_author_img d-flex">
                                    <img src="assets/images/main_images/roger.png" alt="Author">
                                    <div class="author_section">
                                        <h4> Roger Rester</h4>
                                        <p class="para">Home Schooling Parent</p>
                                    </div>
                                </div>
                                <!-- / Testimonial Image -->

                            </div>
                            <!-- / Testimonial -->

                        </div>
                        <!-- / Testimonial Carousel -->
                    </div>
                </div>
            </div>
        </section>
        <!-- Testimonials Section End -->

                        
        <?php include 'footer.php';?>