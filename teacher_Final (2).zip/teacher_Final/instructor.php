<?php include 'header.php';?>

<!-- BANNER WORKS STARTS HERE -->
<div class="container-fluid about-banner">
    <div class="row">
        <div class="col-lg-2">

        </div>

        <div class="col-lg-8" data-aos="fade-down"
     data-aos-easing="linear"
     data-aos-duration="1000">
        <h2>Instructor</h2>
        <p>"At Parents2Teacher, our instructors are dedicated to empowering student success. Through innovative methods and individualized guidance, we're committed to making teaching both engaging and impactful for all."</p>
        </div>

        <div class="col-lg-2">
            
        </div>
    </div>
   </div>
<!-- BANNER WORKS ENDS HERE -->

<div class="container  mt-50">

<div class="row justify-content-center">
                    <div class="col-xl-6 col-lg-7 col-md-8">
                        <div class="section-title text-center mb-40">
                            <h6 class="best_popular_heading"> Featured Instructors</h6>
                            <h2 class="best_popular_heading_two">Our Popular Instructor</h2>
                        </div>
                    </div>
                </div>
  <div class="row">
  <div class="col-lg-4  col-md-4  col-sm-6 detail-inst instructor-page mt-20 mb-20">
            
            <div class="detail-inst-info">
            <img src="assets/images/course/ins1.webp" alt="" class="img">
            <div class="icon10 d-flex flex-column">
            <span>John Elvis</span>
            <span class="fs-5">Computer Science</span>
            <div>
            <i class="fab fa-facebook"></i>
            <i class="fab fa-instagram"></i>
            <i class="fab fa-youtube"></i>
            <i class="fab fa-tiktok"></i>
            </div>
            </div>
            </div>
        </div>

        <div class="col-lg-4  col-md-4 col-sm-6 detail-inst instructor-page mt-20 mb-20">
            <div class="detail-inst-info">
            <img src="assets/images/course/inst2.jpg" alt="" class="img">
            <div class="icon10 d-flex flex-column">
            <span>Nathan</span>
            <span class="fs-5">AI Specialist</span>
            <div>
            <i class="fab fa-facebook"></i>
            <i class="fab fa-instagram"></i>
            <i class="fab fa-youtube"></i>
            <i class="fab fa-tiktok"></i>
            </div>
            </div>
            </div>
        </div>

        <div class="col-lg-4  col-md-4 col-sm-6 detail-inst instructor-page mt-20 mb-20">
            <div class="detail-inst-info">
            <img src="assets/images/course/ins3.webp" alt="" class="img">
            <div class="icon10 d-flex flex-column">
            <span>Joe Root</span>
            <span class="fs-5">English Language</span>
            <div>
            <i class="fab fa-facebook"></i>
            <i class="fab fa-instagram"></i>
            <i class="fab fa-youtube"></i>
            <i class="fab fa-tiktok"></i>
            </div>
            </div>
            </div>
        </div>

        <div class="col-lg-4  col-md-4 col-sm-6 detail-inst  instructor-page mt-20 mb-20">
            <div class="detail-inst-info">
            <img src="assets/images/course/ins4.webp" alt="" class="img">
            <div class="icon10 d-flex flex-column">
            <span>Mariya Jones</span>
            <span class="fs-5">Physics Lecturer</span>
            <div>
            <i class="fab fa-facebook"></i>
            <i class="fab fa-instagram"></i>
            <i class="fab fa-youtube"></i>
            <i class="fab fa-tiktok"></i>
            </div>
            </div>
            </div>
        </div>


        <div class="col-lg-4  col-md-4 col-sm-6 detail-inst instructor-page mt-20 mb-20">
            <div class="detail-inst-info">
            <img src="assets/images/course/ins5.webp" alt="" class="img">
            <div class="icon10 d-flex flex-column">
            <span>Aless Mark</span>
            <span class="fs-5">DigItal MARKETING</span>
            <div>
            <i class="fab fa-facebook"></i>
            <i class="fab fa-instagram"></i>
            <i class="fab fa-youtube"></i>
            <i class="fab fa-tiktok"></i>
            </div>
            </div>
            </div>
        </div>

        <div class="col-lg-4  col-md-4 col-sm-6 detail-inst instructor-page mt-20 mb-20">
            <div class="detail-inst-info">
            <img src="assets/images/course/ins6.webp" alt="" class="img">
            <div class="icon10 d-flex flex-column">
            <span>Michel Bracewell</span>
            <span class="fs-5">Data Scientist</span>
            <div>
            <i class="fab fa-facebook"></i>
            <i class="fab fa-instagram"></i>
            <i class="fab fa-youtube"></i>
            <i class="fab fa-tiktok"></i>
            </div>
            </div>
            </div>
        </div>





      
  </div>
</div>


<?php include 'footer.php';?>