<?php include 'header.php';?>


<!-- BANNER WORKS STARTS HERE -->
<div class="container-fluid about-banner">
    <div class="row">
        <div class="col-lg-2">

        </div>

        <div class="col-lg-8" data-aos="fade-down"
     data-aos-easing="linear"
     data-aos-duration="1000">
        <h2>ABOUT US</h2>
        <p>"At Parents2Teacher, we're passionate about empowering students to succeed. With innovative programs and personalized support, we're here to make learning engaging and effective for everyone.</p>  

        </div>

        <div class="col-lg-2">
            
        </div>
    </div>
    </div>

<!-- BANNER WORKS ENDS HERE -->

<!-- Choose Our Services starts here -->
<div class="container choose-service my-20 mb-250">
    <div class="row">
        <div class="col-lg-6 col-md-6 choose-img pt-20" data-aos="fade-right"
     data-aos-offset="300"
     data-aos-easing="ease-in-sine" >
            <img src="assets/images/about/choose-img.webp" alt="">
        </div>

        <div class="col-lg-6 col-md-6 why-choose pt-20 pl-40" data-aos="fade-left"
     data-aos-offset="300"
     data-aos-duration="500">
            <span class="text-yellow ">ABOUT COMPANY</span>
            <div class="choose-line"></div>
            <h2 class="pt-20">Why Choose Our Education Services</h2>
            <p>Empowering students with tailored learning experiences and comprehensive academic support and transforming education through innovative programs and personalized guidance.</p>
            <div class="row pt-20">
                <div class="col-lg-6 col-md-6 col-sm-6 col-6">
                    <div class="why-icon-style">
                    <i class="fa-solid fa-print"></i>
                    <span class="d-flex align-items-center"><a href="">Quality Education</a></span>
                    </div>
                </div>

                <div class="col-lg-6 col-md-6 col-sm-6 col-6">
                    <div class="why-icon-style">
                    <i class="fa-solid fa-circle-check"></i>
                    <span class="d-flex align-items-center"><a href="">Upgrades Skills</a></span>
                    </div>
                </div>
            </div>
            <p class="pt-40 ">We're here to make learning easier for everyone. We offer different ways to help you learn better, like tutoring and getting ready for tests. Our goal is to help you succeed by teaching you how to think and by supporting you in a friendly environment. We're always working hard to give you the best education possible</p>
            <button class="btn btn-primary coach-btn">
                    <a href="#"> Explore More</a>
                </button>
        </div>
    </div>
</div>
<!-- Choose Our Services ends here -->


<!-- third part of services strats here -->
<div class="container-fluid about-section3 py-30 my-30">
<div class="container choose1-service">
    <div class="row mt-50">
    <div class="col-lg-4 col-md-4 col-sm-4 col-6" data-aos="fade-down"
     data-aos-easing="linear"
     data-aos-duration="500">
        <div class="about-cards text-center">
                           
             <i class="fa-solid fa-image icon3"></i>
                               <h5 class="about-card-text">15K+</h5>
                               <span class="about-card-text2">Projects Completed</span>
                           </div>
        </div>

        <div class="col-lg-4 col-md-4 col-sm-4 col-6" data-aos="fade-down"
     data-aos-easing="linear"
     data-aos-duration="1000">
        <div class="about-cards text-center">
        <i class="fa-solid fa-user icon3"></i>

                               <h5 class="about-card-text">10k+</h5>
                               <span class="about-card-text2">Students Enrollment</span>
                           </div>
        </div>

        <div class="col-lg-4 col-md-4 col-sm-4 col-6 choose1-service-center" data-aos="fade-down"
     data-aos-easing="linear"
     data-aos-duration="1500">
        <div class="about-cards text-center">
        <i class="fa-solid fa-message icon3"></i>           
                               <h5 class="about-card-text">100k+</h5>
                               <span class="about-card-text2">Courses</span>
                           </div>
        </div>
    </div>
</div>>

<div class="container choose2-service my-30">
    <div class="row">

        <div class="col-lg-6 col-md-6 why-choose pt-20" data-aos="fade-right"
     data-aos-offset="300"
     data-aos-easing="ease-in-sine">
            <span class="text-white ">WHY SHOULD CHOOSE US</span>
            <div class="choose-line bg-white"></div>
            <h2 class="pt-20 text-white">Leading in Quality Education</h2>
            <p class="text-white">Empowering students with tailored learning experiences and comprehensive academic support and transforming education through innovative programs and personalized guidance.</p>
        </div>

        <div class="col-lg-6 col-md-6 pt-20" data-aos="fade-left"
     data-aos-offset="300"
     data-aos-duration="500">
        <img src="assets/images/about/choose4.jpg" alt="" class="choose-img2">
        </div>
    </div>
</div>
</div>

<!-- third part of services ends here -->


<!-- Choose second Our Services starts here -->
<div class="container choose2-service">
    <div class="row">

        <div class="col-12 why-choose why-choose1  pt-20" data-aos="fade-right"
     data-aos-offset="300"
     data-aos-easing="ease-in-sine">
            <span class="text-yellow ">WHY SHOULD CHOOSE US</span>
            <div class="choose-line"></div>
            <h2 class="pt-20">We Provide Quality Education </h2>
            <p class="text-center">Empowering students with tailored learning experiences and comprehensive academic support and transforming education through innovative programs and personalized guidance.</p>
        </div>
    </div>
</div>
<!-- Choose second Our Services ends here -->




        <!-- course start -->
        <section class="course">
        
            <div class="container">
                <div class="row mb-5">
                    <div class="col-lg-3 col-md-6 col-sm-6 col-12 mt-3" data-aos="fade-down"
     data-aos-easing="linear"
     data-aos-duration="500">
                        <div class="about-cards">
                        <i class="fa-solid fa-house"></i>

                            <h5 class="">Home Projects</h5>
                            <p class="">Innovative hands-on assignments cultivating creativity and practical skills at home
                                
                            </p>

                        </div>
                    </div>

                    <div class="col-lg-3 col-md-6 col-sm-6 col-12 mt-3" data-aos="fade-down"
     data-aos-easing="linear"
     data-aos-duration="1000">
                        <div class="about-cards">
                        <i class="fa-solid fa-globe icon2"></i>

                            <h5 class="">Online Classes</h5>
                            <p class="">Flexible, accessible learning platform fostering global education and collaboration online.
                               
                            </p>

                        </div>
                    </div>

                    <div class="col-lg-3 col-md-6 col-sm-6 col-12 mt-3" data-aos="fade-down"
     data-aos-easing="linear"
     data-aos-duration="1500">
                        <div class="about-cards">
                           
                        <i class="fa-solid fa-book-open"></i>
                            <h5 class="">Book Library</h5>
                            <p class="">Vast repository offering diverse knowledge and immersive experiences for readers.
  </p>
                        </div>
                    </div>

                    <div class="col-lg-3 col-md-6 col-sm-6 col-12 mt-3" data-aos="fade-down"
     data-aos-easing="linear"
     data-aos-duration="2000">
                        <div class="about-cards">
                      
                        <i class="fa-solid fa-graduation-cap icon2"></i>
                            <h5 class="">Skilled Instructors</h5>
                            <p class="">Experienced mentors providing personalized guidance for academic.
                            </p>
                        </div>
                    </div>

                    

                </div>
            </div>
          
        </section>
        <!-- course end -->
        <?php include 'footer.php';?>