<?php include 'header.php';?>

<!-- BANNER WORKS STARTS HERE -->
<div class="container-fluid about-banner">
    <div class="row">
        <div class="col-lg-2">

        </div>

        <div class="col-lg-8" data-aos="fade-down"
     data-aos-easing="linear"
     data-aos-duration="1000">
        <h2>Contact Us</h2>
        
<p>"At Parents2Teacher, connecting with us is easy. We're committed to empowering student success through innovative programs and personalized support. Reach out today and let's make learning engaging and effective for everyone."</p>
        </div>

        <div class="col-lg-2">
            
        </div>
    </div>
   </div>
<!-- BANNER WORKS ENDS HERE -->

 <!-- main section of contact us -->
<section class="contact-main">
    <div class="container contact-main-detail"  data-aos="fade-down"
     data-aos-easing="linear"
     data-aos-duration="1000" >
        <div class="row">
            <div class="col-lg-6 col-md-6 pt-3" >
              <h3>FOR MORE DETAILS</h3>
              <h3>CONTACT US!</h3>
              <div class="line"></div>
              <p class="pt-3">We're here to help! Whether you have questions, feedback, or just want to say hello, feel free to reach out to us. Our team is dedicated to providing timely and personalized assistance to ensure your experience with us is nothing short of exceptional.</p>
            </div>


            <div class="col-lg-6 col-md-6 pt-3">
            <form class="row g-3">
  <div class="col-md-6">
    <label for="inputEmail4" class="form-label">Email</label>
    <input type="email" class="form-control" id="inputEmail4">
  </div>
  <div class="col-md-6">
    <label for="inputPassword4" class="form-label">Password</label>
    <input type="password" class="form-control" id="inputPassword4">
  </div>
  <div class="col-12">
    <label for="inputAddress" class="form-label">Address</label>
    <input type="text" class="form-control" id="inputAddress" placeholder="1234 Main St">
  </div>
  <div class="col-12">
    <label for="inputAddress2" class="form-label">Address 2</label>
    <input type="text" class="form-control" id="inputAddress2" placeholder="Apartment, studio, or floor">
  </div>
  <div class="col-md-6">
    <label for="inputCity" class="form-label">City</label>
    <input type="text" class="form-control" id="inputCity">
  </div>
  <div class="col-md-4">
    <label for="inputState" class="form-label">State</label>
    <select id="inputState" class="form-select">
      <option selected>Choose...</option>
      <option>...</option>
    </select>
  </div>

  <div class="col-12">
    <div class="form-check">
      <input class="form-check-input form-check-input2" type="checkbox" id="gridCheck">
      <label class="form-check-label" for="gridCheck">
        Check me out
      </label>
    </div>
  </div>
  <div class="col-12">
    <button type="submit" class="btn btn-primary">Sign in</button>
  </div>
</form>


            </div>
        </div>
    </div>

</section>


<?php include 'footer.php';?>