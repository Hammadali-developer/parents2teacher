<?php include 'header.php';?>


        <!--Form Back Drop-->
        <div class="form-back-drop"></div>
        <!-- Hero Section Start -->
        <section class="hero-section rel z-1">
            <div class="container">
                
                <div class="row align-items-center pt-4">
                    
                    <div class="col-lg-12 col-md-12 col-12">
                        <div class="hero-content ">

                            <h1 class="mb-20 wow fadeInUp delay-0-4s text-center big_heading">Sign Up</h1>
                            
                        </div>
                    </div>
                    
                </div>
            </div>
            <span class="bg-text">coach</span>
        </section>
        <!-- Hero Section End -->

        <!--   -->
        <!-- MultiStep Form -->
        <section class="multiform_section">
            <div class="container-fluid">
                <div class="row justify-content-center">
                    <div class="col-12 col-sm-10 col-md-12 col-lg-11 col-xl-8 text-center p-0 mt-3 mb-2">
                        <div class="card px-0 pt-4 pb-0 mt-3 mb-3">
                            <!-- <h2 id="heading">Sign Up Your User Account</h2>
                            <p>Fill all form field to go to next step</p> -->
                            <form id="msform">
                                <!-- progressbar -->
                                <ul id="progressbar">
                                    <li class="active" id="account">
                                        <img src="assets/images/main_images/Number.png" alt="number">
                                    </li>
                                    <li id="personal">
                                        <img src="assets/images/main_images/Number (2).png" alt="number">
                                    </li>
                                    <li id="payment">
                                        <img src="assets/images/main_images/Number (3).png" alt="number">

                                    </li>
                                    <li id="confirm"><strong>Finish</strong></li>
                                </ul>
                                <div class="progress">
                                    <div class="progress-bar progress-bar-striped progress-bar-animated"
                                        role="progressbar" aria-valuemin="0" aria-valuemax="100"></div>
                                </div> <br> <!-- fieldsets -->
                                <fieldset>
                                    <div class="form-card">
                                        <div class="row">
                                            <div class="col-12 col-md-7 col-lg-7">
                                                <!-- <h2 class="fs-title">Account Information:</h2> -->
                                            </div>
                                            <div class="col-5">
                                                <h2 class="steps">Step 1 - 4</h2>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-12  col-md-7 col-lg-6">
                                               
                                                <h2 class="fs-title">Enter Your Details</h2>
                                                <!-- <label class="fieldlabels">Username:*</label> -->
                                                <input type="text" name="uname" placeholder="Enter Name" />
                                                <!-- <label class="fieldlabels">Email: *</label> -->
                                                <input type="email" name="email" placeholder="Enter E-mail Address" />
                                                <!-- <label class="fieldlabels">Password: *</label> -->
                                                <input type="password" name="pwd" placeholder="Create Password" />
                                                <!-- <label class="fieldlabels">Confirm Password: *</label> -->
                                                <input type="password" name="cpwd" placeholder="Re-enter Password" />
                                            </div>
                                            <div class="col-6">
                                                <h2 class="fs-title">I Want To Sign Up</h2>
                                                <div class="form-check">
                                                    <label class="form-check-label radio_lable" for="flexRadioDefault1">
                                                        As Parent
                                                    </label>
                                                    <input class="form-check-input radio_input" type="radio"
                                                        name="flexRadioDefault" id="flexRadioDefault1" checked>
                                                </div>

                                                <div class="form-check">
                                                    <label class="form-check-label radio_lable" for="flexRadioDefault1">
                                                        As Teacher
                                                    </label>
                                                    <input class="form-check-input radio_input" type="radio"
                                                        name="flexRadioDefault" id="flexRadioDefault1">
                                                </div>
                                                <div class="form-check">
                                                    <label class="form-check-label radio_lable" for="flexRadioDefault1">
                                                        As Business/School
                                                    </label>
                                                    <input class="form-check-input radio_input" type="radio"
                                                        name="flexRadioDefault" id="flexRadioDefault1">
                                                    
                                                </div>
                                                <button class="btn btn-primary form-btn">
                                                        <a href="#"> Proceed Ahead</a>
                                                    </button>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <input type="button" name="next" class="next action-button ntx_btn" value="Next" />
                                  
                                </fieldset>

                                <fieldset>
                                     <!-- Blog Section Start -->
        <section class="blog-section">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-xl-12 col-lg-12 col-md-12">
                        <div class="section-title text-left mb-55">
                            <h2 class="blog_heading">Choose What Fits You Best</h2>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-4 col-md-6 col-12">
                   
                        <div class="blog-item wow fadeInUp delay-0-6s">
                            <div class="blog-content">
                                <!-- <span class="date"><span>03</span> April</span> -->
                                <div class="blog_content">
                                    <div class="d-flex align-items-center justify-content-between">
                                        <h3>Base Plan</h3>
                                        <h4>$30.00 / mo</h4>
                                    </div>
                                    <span class="inculded">What’s Inculded?</span>

                                    <ul class="blog_unorderd">
                                        <li>Lorem ipsum dolor sit amet, consec.</li>
                                        <li>Lorem ipsum dolor sit amet, consec.</li>
                                        <li>Lorem ipsum dolor sit amet, consec.</li>
                                        <li>Lorem ipsum dolor sit amet, consec.</li>
                                        <li>Lorem ipsum dolor sit amet, consec.</li>
                                        <li>Lorem ipsum dolor sit amet, consec.</li>
                                        <li>Lorem ipsum dolor sit amet, consec.</li>
                                        <li>Lorem ipsum dolor sit amet, consec.</li>
                                        <li>Lorem ipsum dolor sit amet, consec.</li>
                                        <li>Lorem ipsum dolor sit amet, consec.</li>

                                    </ul>
                                    <a href="#" class="blog_btn">Choose Plan</a>
                                    <!-- <ul class="blog-meta">
                                <li><i class="far fa-user"></i> <a href="blog.html">By Somalia</a></li>
                                <li><i class="far fa-comments"></i> <a href="blog.html">Com (5)</a></li>
                            </ul> -->
                                    <!-- <h5><a href="blog-details.html">Useful VS Code Esions Front-End Develop</a></h5>
                            <p>Sit amet consectetur adiscins eiusmod tempor incididunt</p>
                            <a href="blog-details.html" class="read-more">Read more <i
                                    class="fas fa-arrow-right"></i>
                                </a> -->
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-12">
                        <div class="blog-item wow fadeInUp delay-0-6s">
                            <!-- <div class="blog-image">
                        <img src="assets/images/blog/blog3.jpg" alt="Blog">
                    </div> -->
                            <div class="blog-content">
                                <div class="blog_content">
                                    <div class="d-flex align-items-center justify-content-between">
                                        <h3>Silver Plan</h3>
                                        <h4>$49.99 / mo</h4>
                                    </div>
                                    <span class="inculded">What’s Inculded?</span>

                                    <ul class="blog_unorderd">
                                        <li>Lorem ipsum dolor sit amet, consec.</li>
                                        <li>Lorem ipsum dolor sit amet, consec.</li>
                                        <li>Lorem ipsum dolor sit amet, consec.</li>
                                        <li>Lorem ipsum dolor sit amet, consec.</li>
                                        <li>Lorem ipsum dolor sit amet, consec.</li>
                                        <li>Lorem ipsum dolor sit amet, consec.</li>
                                        <li>Lorem ipsum dolor sit amet, consec.</li>
                                        <li>Lorem ipsum dolor sit amet, consec.</li>
                                        <li>Lorem ipsum dolor sit amet, consec.</li>
                                        <li>Lorem ipsum dolor sit amet, consec.</li>

                                    </ul>
                                    <a href="#" class="blog_btn">Choose Plan</a>

                                   
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-12">

                        <div class="blog-item wow fadeInUp delay-0-6s">
                            
                            <div class="blog-content">
                                <div class="blog_content">
                                    <div class="d-flex align-items-center justify-content-between">
                                        <h3>Gold Plan</h3>
                                        <h4>$99.99 / mo</h4>
                                    </div>
                                    <span class="inculded">What’s Inculded?</span>

                                    <ul class="blog_unorderd">
                                        <li>Lorem ipsum dolor sit amet, consec.</li>
                                        <li>Lorem ipsum dolor sit amet, consec.</li>
                                        <li>Lorem ipsum dolor sit amet, consec.</li>
                                        <li>Lorem ipsum dolor sit amet, consec.</li>
                                        <li>Lorem ipsum dolor sit amet, consec.</li>
                                        <li>Lorem ipsum dolor sit amet, consec.</li>
                                        <li>Lorem ipsum dolor sit amet, consec.</li>
                                        <li>Lorem ipsum dolor sit amet, consec.</li>
                                        <li>Lorem ipsum dolor sit amet, consec.</li>
                                        <li>Lorem ipsum dolor sit amet, consec.</li>

                                    </ul>
                                    <a href="#" class="blog_btn">Choose Plan</a>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Blog Section End -->
                                    <input type="button" name="next" class="next action-button ntx_btn" value="Proceed Ahead" />
                                    <input type="button" name="previous" class="previous action-button-previous ntx_btn"
                                        value="Back" />
                                </fieldset>

                                <fieldset>
                                    <div class="form-card">
                                        <div class="row">
                                            <div class="col-7">
                                                <h2 class="fs-title">Confirm Subscription To <span
                                                        class="fs-title-span">Silver Plan</span></h2>
                                            </div>

                                            <div class="col-5">
                                                <h2 class="steps">Step 2 - 4</h2>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6 col-6">
                                            <h2 class="fs-silver">Silver Plan </h2>

                                            </div>
                                            <div class="col-md-6 col-6">
                                            <h2 class="fs-count">$49.99/mo</h2>

                                            </div>
                                        </div>
                                        <div class="row">
                                                    <div class="col-md-6">
                                                         <!-- <label class="fieldlabels">First Name: *</label> -->
                                                        <input type="text" name="fname" placeholder="Cardholder Name" />
                                                    </div>
                                                    <div class="col-md-6">
                                                        <!-- <label class="fieldlabels">Contact No.: *</label> -->
                                                   <input type="number" name="phno" placeholder="xxxx xxxx xxxx 3456" />
                                                </div>

                                        </div>
                                        <div class="row">
                                            <div class="col-md-4">
                                                  <!-- <label class="fieldlabels">Alternate Contact No.: *</label> -->
                                        <input type="text" name="phno" placeholder="CVV/CVC" />
                                            </div>
                                            <div class="col-md-4">
                                        <input type="date" name="expiry_month" placeholder="Expiry Month" />

                                            </div>
                                            <div class="col-md-4">
                                        <input type="date" name="expiry_year" placeholder="Expiry Year" />

                                            </div>
                                        </div>
                                    </div>
                                    <input type="button" name="next" class="next action-button ntx_btn"
                                        value="Confirm Payment" />
                                    <input type="button" name="previous" class="previous action-button-previous ntx_btn"
                                        value="Back" />
                                </fieldset>
                                <fieldset>
                                    <div class="form-card">
                                        <div class="row">
                                            <div class="col-7">
                                                <h2 class="fs-title">Complete Your Profile</h2>
                                            </div>
                                            <div class="col-5">
                                                <h2 class="steps">Step 3 - 4</h2>
                                            </div>
                                        </div>
                                        <!-- <label class="fieldlabels">Upload Your Photo:</label> <input type="file"
                                            name="pic" accept="image/*"> <label class="fieldlabels">Upload Signature
                                            Photo:</label> <input type="file" name="pic" accept="image/*"> -->
                                    </div>
                                    <a href="dashboard.php">
                                    <input type="button" name="next" class="next action-button ntx_btn"
                                        value="Save & Proceed To Dashboard" /></a>
                                    <input type="button" name="previous" class="previous action-button-previous ntx_btn"
                                        value="Skip & Proceed To Dashboard" />
                                </fieldset>
                                <fieldset>
                                    <div class="form-card">
                                        <div class="row">
                                            <div class="col-7">
                                                <h2 class="fs-title">Finish:</h2>
                                            </div>
                                            <div class="col-5">
                                                <h2 class="steps">Step 4 - 4</h2>
                                            </div>
                                        </div> <br><br>
                                        <h2 class="purple-text text-center"><strong>SUCCESS !</strong></h2> <br>
                                        <div class="row justify-content-center">
                                            <div class="col-3"> <img src="https://i.imgur.com/GwStPmg.png"
                                                    class="fit-image"> </div>
                                        </div> <br><br>
                                        <div class="row justify-content-center">
                                            <div class="col-7 text-center">
                                                <h5 class="purple-text text-center">You Have Successfully Signed Up</h5>
                                            </div>
                                        </div>
                                    </div>
                                </fieldset>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- /.MultiStep Form -->
        <?php include 'footer.php';?>