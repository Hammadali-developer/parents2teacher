<?php include 'header.php';?>

<!-- BANNER WORKS STARTS HERE -->
<div class="container-fluid about-banner">
    <div class="row">
        <div class="col-lg-2">

        </div>

        <div class="col-lg-8" data-aos="fade-down"
     data-aos-easing="linear"
     data-aos-duration="1000">
        <h2>COURSES</h2>

        <p>"At Parents2Teacher, our courses are designed to ignite student success. Through innovative programs and tailored support, we're dedicated to making learning both captivating and impactful for all."</p>
        </div>

        <div class="col-lg-2">
            
        </div>
    </div>
    </div>

<!-- BANNER WORKS ENDS HERE -->

<section>
<!-- RADIO BUTTON STARTS HERE -->
<div class="container course-form d-flex justify-content-center mt-30">

<div class="form-check">
  <input class="form-check-input form-check-input2" type="radio" name="flexRadioDefault" id="flexRadioDefault1">
  <label class="form-check-label" for="flexRadioDefault1">
    ALL
  </label>
</div>
<div class="form-check  mx-3">
  <input class="form-check-input form-check-input2" type="radio" name="flexRadioDefault" id="flexRadioDefault2" checked>
  <label class="form-check-label" for="flexRadioDefault2">
   FREE
  </label>
</div>


<div class="form-check">
  <input class="form-check-input form-check-input2" type="radio" name="flexRadioDefault" id="flexRadioDefault3" value="option2">
  <label class="form-check-label" for="exampleRadios3">
    PAID
  </label>
</div>
                           
</div>
<!-- RADIO BUTTON ENDS HERE -->

<!-- ORDER lIST  STARTS HERE -->
<div class="container course-orderlist my-20 mb-70">
    <div class="row">
        <div class="col-lg-4 col-md-4 course-icon">
        <i class="bi bi-grid-3x3-gap-fill"></i>
        <i class="bi bi-list-ul"></i>
        </div>

        <div class="col-lg-4 col-md-4">
        <div class="mb-3 d-flex course-search">
   <input type="text" class="form-control" id="formGroupExampleInput" placeholder="Search">
   <i class="bi bi-search"></i>
</div>
        </div>

        <div class="col-lg-4 col-md-4 pb-3">
            <div class="course-drop">
            <span class="px-2 p-1">Order By:</span>
            <!-- <div class="dropdown">
  <button class="btn btn-secondary bg-white text-dark dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
   Select Order
  </button>
  <ul class="dropdown-menu dropdown-menu-dark">
    <li><a class="dropdown-item active" href="#">RECENT ORDER</a></li>
    <li><hr class="dropdown-divider"></li>
    <li><a class="dropdown-item" href="#">hIGHEST PAID</a></li>
    <li><hr class="dropdown-divider"></li>
  </ul>
</div> -->
<div class="dropdown">
  <button class="btn btn-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
    Dropdown button
  </button>
  <ul class="dropdown-menu">
    <li><a class="dropdown-item" href="#">Action</a></li>
    <li><a class="dropdown-item" href="#">Another action</a></li>
    <li><a class="dropdown-item" href="#">Something else here</a></li>
  </ul>
</div>
            </div>
        </div>
    </div>
</div>
<!-- ORDER lIST  ENDS HERE -->
</section>



 <!-- Coach Section Start -->
 <section class="coach-section rel z-1 pt-30 rpt-90 pb-100 rpb-70 bg-lighter">
            <div class="container">
           <div class="row  coach-active justify-content-center">
                    <div class="col-lg-4 col-md-6 col-sm-6 item marketing technology mt-4 mb-4">
                        <div class="coach-bg">
                            <div class="coach-item wow fadeInUp delay-0-2s ">
                                <div class="coach-image">
                                    <!-- <a href="#" class="category">Lifestyle</a> -->
                                    <img src="assets/images/main_images/coach1.png" alt="Coach">
                                </div>
                                <div class="coach-content">
                                    <div class="ratting-price">
                                        <div class="ratting">
                                            <!-- <i class="fas fa-star"></i> -->
                                            <i class="fa-solid fa-user"></i>
                                            <span>30 User</span>
                                        </div>
                                        <div class="ratting">
                                            <i class="fa fa-clock" aria-hidden="true"></i>
                                            <span>12-12-2023</span>
                                        </div>
                                        <div class="ratting">
                                        <i class="fa-solid fa-book"></i>
                                            <span>3 Lessons</span>
                                        </div>
                                    </div>
                                    <h3><a href="detailcourse.php">Mathematics</a></h3>
                                    <p>Enroll in our course and unlock a world of opportunities with expert guidance and hands-on learning</p>                                  
                                    <ul class="coach-footer">
                                    <span class="price">60.00</span>
                                    <div>
                                    <i class="fa-solid fa-star" style="color: #FFD43B;"></i>
                                    <i class="fa-solid fa-star" style="color: #FFD43B;"></i>
                                    <i class="fa-solid fa-star" style="color: #FFD43B;"></i>
                                    <i class="fa-solid fa-star" style="color: #FFD43B;"></i>
                                    <i class="fa-regular fa-star" style="color: #FFD43B;"></i>

                                    </div>
                                            
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-6 item design photography mt-4 mb-4">
                        <div class="coach-bg">
                            <div class="coach-item wow fadeInUp delay-0-4s">
                                <div class="coach-image">
                                    <!-- <a href="#" class="category">Lifestyle</a> -->
                                    <img src="assets/images/main_images/coach2.png" alt="Coach">
                                </div>
                                <div class="coach-content">
                                    <div class="ratting-price">
                                        <div class="ratting">
                                            <!-- <i class="fas fa-star"></i> -->
                                            <i class="fa-solid fa-user"></i>
                                            <span>30 User</span>
                                        </div>
                                        <div class="ratting">
                                            <i class="fa fa-clock" aria-hidden="true"></i>
                                            <span>12-dec-2023</span>
                                        </div>
                                        <div class="ratting">
                                        <i class="fa-solid fa-book"></i>
                                            <span>3 Lessons</span>
                                        </div>
                                    </div>
                                    <h3><a href="detailcourse.php">Computer Science</a></h3> 
                                    <p>Enroll in our course and unlock a world of opportunities with expert guidance and hands-on learning</p>                                     
                                    <ul class="coach-footer">
                                    <span class="price">60.00</span>
                                    <div>
                                    <i class="fa-solid fa-star" style="color: #FFD43B;"></i>
                                    <i class="fa-solid fa-star" style="color: #FFD43B;"></i>
                                    <i class="fa-solid fa-star" style="color: #FFD43B;"></i>
                                    <i class="fa-solid fa-star" style="color: #FFD43B;"></i>
                                    <i class="fa-regular fa-star" style="color: #FFD43B;"></i>

                                    </div>
                                            
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-6 item development photography mt-4 mb-4">
                        <div class="coach-bg">
                            <div class="coach-item wow fadeInUp delay-0-6s">
                                <div class="coach-image">
                                    <!-- <a href="#" class="category">Lifestyle</a> -->
                                    <img src="assets/images/main_images/coach3.png" alt="Coach">
                                </div>
                                <div class="coach-content">
                                    <div class="ratting-price">
                                        <div class="ratting">
                                            <!-- <i class="fas fa-star"></i> -->
                                            <i class="fa-solid fa-user"></i>
                                            <span>30 User</span>
                                        </div>
                                        <div class="ratting">
                                            <i class="fa fa-clock" aria-hidden="true"></i>
                                            <span>12-dec-2023</span>
                                        </div>
                                        <div class="ratting">
                                        <i class="fa-solid fa-book"></i>
                                            <span>3 Lessons</span>
                                        </div>
                                    </div>
                                    <h3><a href="detailcourse.php">Digital Marketing</a></h3> 
                                    <p>Enroll in our course and unlock a world of opportunities with expert guidance and hands-on learning</p>                                     
                                    <ul class="coach-footer">
                                    <span class="price">60.00</span>
                                    <div>
                                    <i class="fa-solid fa-star" style="color: #FFD43B;"></i>
                                    <i class="fa-solid fa-star" style="color: #FFD43B;"></i>
                                    <i class="fa-solid fa-star" style="color: #FFD43B;"></i>
                                    <i class="fa-solid fa-star" style="color: #FFD43B;"></i>
                                    <i class="fa-regular fa-star" style="color: #FFD43B;"></i>

                                    </div>
                                            
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-6 item design technology mt-4 mb-4">
                        <div class="coach-bg">
                            <div class="coach-item wow fadeInUp delay-0-2s">
                                <div class="coach-image">
                                    <!-- <a href="#" class="category">Lifestyle</a> -->
                                    <img src="assets/images/main_images/coach4.png" alt="Coach">
                                </div>
                                <div class="coach-content">
                                    <div class="ratting-price">
                                        <div class="ratting">
                                            <!-- <i class="fas fa-star"></i> -->
                                            <i class="fa-solid fa-user"></i>
                                            <span>30 User</span>
                                        </div>
                                        <div class="ratting">
                                            <i class="fa fa-clock" aria-hidden="true"></i>
                                            <span>12-dec-2023</span>
                                        </div>
                                        <div class="ratting">
                                        <i class="fa-solid fa-book"></i>
                                            <span>3 Lessons</span>
                                        </div>
                                    </div>
                                    <h3><a href="detailcourse.php">Chemistry</a></h3> 
                                    <p>Enroll in our course and unlock a world of opportunities with expert guidance and hands-on learning</p>                                     
                                    <ul class="coach-footer">
                                    <span class="price">60.00</span>
                                    <div>
                                    <i class="fa-solid fa-star" style="color: #FFD43B;"></i>
                                    <i class="fa-solid fa-star" style="color: #FFD43B;"></i>
                                    <i class="fa-solid fa-star" style="color: #FFD43B;"></i>
                                    <i class="fa-solid fa-star" style="color: #FFD43B;"></i>
                                    <i class="fa-regular fa-star" style="color: #FFD43B;"></i>

                                    </div>
                                            
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6  col-sm-6 item development photography mt-4 mb-4">
                        <div class="coach-bg">
                            <div class="coach-item wow fadeInUp delay-0-4s">
                                <div class="coach-image">
                                    <!-- <a href="#" class="category">Lifestyle</a> -->
                                    <img src="assets/images/main_images/coach5.png" alt="Coach">
                                </div>
                                <div class="coach-content">
                                    <div class="ratting-price">
                                        <div class="ratting">
                                            <!-- <i class="fas fa-star"></i> -->
                                            <i class="fa-solid fa-user"></i>
                                            <span>30 User</span>
                                        </div>
                                        <div class="ratting">
                                            <i class="fa fa-clock" aria-hidden="true"></i>
                                            <span>12-dec-2023</span>
                                        </div>
                                        <div class="ratting">
                                        <i class="fa-solid fa-book"></i>
                                            <span>3 Lessons</span>
                                        </div>
                                    </div>
                                    <h3><a href="detailcourse.php">Affiliate Marketing</a></h3>  
                                    <p>Enroll in our course and unlock a world of opportunities with expert guidance and hands-on learning</p>                                    
                                    <ul class="coach-footer">
                                    <span class="price">60.00</span>
                                    <div>
                                    <i class="fa-solid fa-star" style="color: #FFD43B;"></i>
                                    <i class="fa-solid fa-star" style="color: #FFD43B;"></i>
                                    <i class="fa-solid fa-star" style="color: #FFD43B;"></i>
                                    <i class="fa-solid fa-star" style="color: #FFD43B;"></i>
                                    <i class="fa-regular fa-star" style="color: #FFD43B;"></i>

                                    </div>
                                            
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6  col-sm-6 item design technology mt-4 mb-4">
                        <div class="coach-bg">
                            <div class="coach-item wow fadeInUp delay-0-6s">
                                <div class="coach-image">
                                    <!-- <a href="#" class="category">Lifestyle</a> -->
                                    <img src="assets/images/main_images/coach6.png" alt="Coach">
                                </div>
                                <div class="coach-content">
                                    <div class="ratting-price">
                                        <div class="ratting">
                                            <!-- <i class="fas fa-star"></i> -->
                                            <i class="fa-solid fa-user"></i>
                                            <span>30 User</span>
                                        </div>
                                        <div class="ratting">
                                            <i class="fa fa-clock" aria-hidden="true"></i>
                                            <span>12-dec-2023</span>
                                        </div>
                                        <div class="ratting">
                                        <i class="fa-solid fa-book"></i>
                                            <span>3 Lessons</span>
                                        </div>
                                    </div>
                                    <h3><a href="detailcourse.php">Artificial Intelligence</a></h3>
                                    <p>Enroll in our course and unlock a world of opportunities with expert guidance and hands-on learning</p>                                      
                                    <ul class="coach-footer">
                                    <span class="price">60.00</span>
                                    <div>
                                    <i class="fa-solid fa-star" style="color: #FFD43B;"></i>
                                    <i class="fa-solid fa-star" style="color: #FFD43B;"></i>
                                    <i class="fa-solid fa-star" style="color: #FFD43B;"></i>
                                    <i class="fa-solid fa-star" style="color: #FFD43B;"></i>
                                    <i class="fa-regular fa-star" style="color: #FFD43B;"></i>

                                    </div>
                                            
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6  col-sm-6 item design technology mt-4 mb-4">
                        <div class="coach-bg">
                            <div class="coach-item wow fadeInUp delay-0-6s">
                            <div class="coach-image">
                                    <!-- <a href="#" class="category">Lifestyle</a> -->
                                    <img src="assets/images/main_images/coach2.png" alt="Coach">
                                </div>
                                <div class="coach-content">
                                    <div class="ratting-price">
                                        <div class="ratting">
                                            <!-- <i class="fas fa-star"></i> -->
                                            <i class="fa-solid fa-user"></i>
                                            <span>30 User</span>
                                        </div>
                                        <div class="ratting">
                                            <i class="fa fa-clock" aria-hidden="true"></i>
                                            <span>12-dec-2023</span>
                                        </div>
                                        <div class="ratting">
                                        <i class="fa-solid fa-book"></i>
                                            <span>3 Lessons</span>
                                        </div>
                                    </div>
                                    <h3><a href="detailcourse.php">Career Counselling</a></h3>
                                    <p>Enroll in our course and unlock a world of opportunities with expert guidance and hands-on learning</p>                                      
                                    <ul class="coach-footer">
                                    <span class="price">60.00</span>
                                    <div>
                                    <i class="fa-solid fa-star" style="color: #FFD43B;"></i>
                                    <i class="fa-solid fa-star" style="color: #FFD43B;"></i>
                                    <i class="fa-solid fa-star" style="color: #FFD43B;"></i>
                                    <i class="fa-solid fa-star" style="color: #FFD43B;"></i>
                                    <i class="fa-regular fa-star" style="color: #FFD43B;"></i>

                                    </div>
                                            
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6  col-sm-6 item design technology mt-4 mb-4">
                        <div class="coach-bg">
                            <div class="coach-item wow fadeInUp delay-0-6s">
                                <div class="coach-image">
                                    <!-- <a href="#" class="category">Lifestyle</a> -->
                                    <img src="assets/images/main_images/coach6.png" alt="Coach">
                                </div>
                                <div class="coach-content">
                                    <div class="ratting-price">
                                        <div class="ratting">
                                            <!-- <i class="fas fa-star"></i> -->
                                            <i class="fa-solid fa-user"></i>
                                            <span>30 User</span>
                                        </div>
                                        <div class="ratting">
                                            <i class="fa fa-clock" aria-hidden="true"></i>
                                            <span>12-dec-2023</span>
                                        </div>
                                        <div class="ratting">
                                        <i class="fa-solid fa-book"></i>
                                            <span>3 Lessons</span>
                                        </div>
                                    </div>
                                    <h3><a href="detailcourse.php">English Pro Course</a></h3>
                                    <p>Enroll in our course and unlock a world of opportunities with expert guidance and hands-on learning</p>                                      
                                    <ul class="coach-footer">
                                    <span class="price">60.00</span>
                                    <div>
                                    <i class="fa-solid fa-star" style="color: #FFD43B;"></i>
                                    <i class="fa-solid fa-star" style="color: #FFD43B;"></i>
                                    <i class="fa-solid fa-star" style="color: #FFD43B;"></i>
                                    <i class="fa-solid fa-star" style="color: #FFD43B;"></i>
                                    <i class="fa-regular fa-star" style="color: #FFD43B;"></i>

                                    </div>
                                            
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6  col-sm-6 item design technology mt-4 mb-4">
                        <div class="coach-bg">
                            <div class="coach-item wow fadeInUp delay-0-6s">
                            <div class="coach-image">
                                    <!-- <a href="#" class="category">Lifestyle</a> -->
                                    <img src="assets/images/main_images/coach4.png" alt="Coach">
                                </div>
                                <div class="coach-content">
                                    <div class="ratting-price">
                                        <div class="ratting">
                                            <!-- <i class="fas fa-star"></i> -->
                                            <i class="fa-solid fa-user"></i>
                                            <span>30 User</span>
                                        </div>
                                        <div class="ratting">
                                            <i class="fa fa-clock" aria-hidden="true"></i>
                                            <span>12-dec-2023</span>
                                        </div>
                                        <div class="ratting">
                                        <i class="fa-solid fa-book"></i>
                                            <span>3 Lessons</span>
                                        </div>
                                    </div>
                                    <h3><a href="detailcourse.php">Stock Market</a></h3>
                                    <p>Enroll in our course and unlock a world of opportunities with expert guidance and hands-on learning</p>                                      
                                    <ul class="coach-footer">
                                    <span class="price">60.00</span>
                                    <div>
                                    <i class="fa-solid fa-star" style="color: #FFD43B;"></i>
                                    <i class="fa-solid fa-star" style="color: #FFD43B;"></i>
                                    <i class="fa-solid fa-star" style="color: #FFD43B;"></i>
                                    <i class="fa-solid fa-star" style="color: #FFD43B;"></i>
                                    <i class="fa-regular fa-star" style="color: #FFD43B;"></i>

                                    </div>
                                            
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </section>
        <!-- Coach Section End -->

<?php include 'footer.php';?>