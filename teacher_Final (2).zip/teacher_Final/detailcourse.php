<?php include 'header.php';?>

<!-- BANNER WORKS STARTS HERE -->
<div class="container-fluid about-banner">
    <div class="row">
        <div class="col-lg-2">

        </div>

        <div class="col-lg-8" data-aos="fade-down"
     data-aos-easing="linear"
     data-aos-duration="1000">
        <h2>DETAILS</h2>
        
<p>"At Parents2Teacher, we're all about helping students do well. We have cool programs and personal help to make learning fun and helpful for everyone. Dive into our courses designed to make tricky subjects easy to understand."</p>
        </div>

        <div class="col-lg-2">
            
        </div>
    </div>
   </div>
<!-- BANNER WORKS ENDS HERE -->


<!-- first list of details starts here -->
<div class="container  mt-50">
    <div class="row details-main1">
        <div class="col-lg-2 col-md-4 detail-alex  ">
        <i class="fa-solid fa-user"></i><br>
        <span class="alex">ALex Hales</span><br>
        <span class="com">Computer Science</span>
        </div>

        <div class="col-lg-7 col-md-8 detail-feature mt-50">
           <div class="d-flex justify-content-between">
           <span class="featured">
            <i class="fa-solid fa-star px-1"></i>
            Featured
            </span>
            <button type="button" class="btn btn-outline-dark">> Onsite</button>
           </div>

           <h2 class="pt-20">Computer Science</h2>

        <div>
        <i class="fa-solid fa-star" style="color: #FFD43B;"></i>
        <i class="fa-solid fa-star" style="color: #FFD43B;"></i>
        <i class="fa-solid fa-star" style="color: #FFD43B;"></i>
        <i class="fa-solid fa-star" style="color: #FFD43B;"></i>
        <i class="fa-solid fa-star" style="color: #FFD43B;"></i>
        <span class="px-2">(2 Reviews)</span>
        </div>
 
 <div class="d-flex detail-available pt-30">
        <div class="text-center" >
        <i class="fa-solid fa-book icon9"></i>
        <p>2 course</p>
        </div>

        <div class="px-4 text-center">
        <i class="fa-solid fa-user-injured icon9"></i>
        <p>33 students</p>
        </div>

        <div class="text-center" >
        <i class="fa-solid fa-desktop icon9"></i>
        <p>0 Seats Available</p>
        </div>

    </div>


        </div>



        <div class="col-lg-3 col-12 detail-cart-main">

        <div class="detail-cart">
            <span>$40</span>
            <button type="button" class="btn btn-outline-success">ADD TO CART</button>

        </div>


        </div>
    </div>
</div>
<!-- first list of details ends here -->

<!-- second list of details starts here -->
<div class="container mt-50 mb-50">
    <div class="row">
        <div class="col-lg-8 col-md-8 mt-20 mb-20">
        <ul class="nav nav-tabs color-nav" id="myTab" role="tablist">
   <li class="nav-item" role="presentation">
    <button class="nav-link active" id="home-tab" data-bs-toggle="tab" data-bs-target="#home-tab-pane" type="button" role="tab" aria-controls="home-tab-pane" aria-selected="true">Courses</button>
  </li>
  <li class="nav-item" role="presentation">
    <button class="nav-link" id="profile-tab" data-bs-toggle="tab" data-bs-target="#profile-tab-pane" type="button" role="tab" aria-controls="profile-tab-pane" aria-selected="false">About</button>
  </li>
  <li class="nav-item" role="presentation">
    <button class="nav-link" id="contact-tab" data-bs-toggle="tab" data-bs-target="#contact-tab-pane" type="button" role="tab" aria-controls="contact-tab-pane" aria-selected="false">Learning Outcomes</button>
  </li>
  <li class="nav-item" role="presentation">
    <button class="nav-link" id="review-tab" data-bs-toggle="tab" data-bs-target="#review-tab-pane" type="button" role="tab" aria-controls="review-tab-pane" aria-selected="false">Reviews</button>
  </li>
 
</ul>
<div class="tab-content pt-30" id="myTabContent">
  <div class="tab-pane fade show active" id="home-tab-pane" role="tabpanel" aria-labelledby="home-tab" tabindex="0">
  <div class="accordion accordion-flush" id="accordionFlushExample">
  <div class="accordion-item">
    <h2 class="accordion-header">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseOne" aria-expanded="false" aria-controls="flush-collapseOne">
     WEB PROGRAMMIMG
      </button>
    </h2>
    <div id="flush-collapseOne" class="accordion-collapse collapse" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body">Lorem ipsum dolor sit amet consectetur adipisicing elit. Tempore, at! Lorem ipsum dolor sit amet consectetur, adipisicing elit. Exercitationem, maiores.</div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseTwo" aria-expanded="false" aria-controls="flush-collapseTwo">
        Logical Building
    </button>
    </h2>
    <div id="flush-collapseTwo" class="accordion-collapse collapse" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body">Lorem ipsum dolor sit amet consectetur adipisicing elit. Reiciendis tempora sit distinctio animi? Eaque quis sunt alias autem vero blanditiis!</div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseThree" aria-expanded="false" aria-controls="flush-collapseThree">
        HANDFUL KNOWLEDGE
      </button>
    </h2>
    <div id="flush-collapseThree" class="accordion-collapse collapse" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body">Lorem ipsum dolor sit amet consectetur adipisicing elit. Modi soluta nulla similique molestias nihil quia ad aut, natus consequatur sequi?</div>
    </div>
  </div>
</div>


  </div>
  <div class="tab-pane fade" id="profile-tab-pane" role="tabpanel" aria-labelledby="profile-tab" tabindex="0">

  <h3 class="pt-20">About Class</h3>
  <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Illum voluptatem tempora, ad, voluptate ab culpa dolore natus nam repellendus quis dolorum. Tempora asperiores eveniet facere assumenda aspernatur rerum ratione ex quidem eos ipsam officia sint labore enim ipsa, aperiam quos!</p>
 </div>
  <div class="tab-pane fade" id="contact-tab-pane" role="tabpanel" aria-labelledby="contact-tab" tabindex="0">
  <h3 class="pt-20">learning Outcomes</h3>
  <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Illum voluptatem tempora, ad, voluptate ab culpa dolore natus nam repellendus quis dolorum. Tempora asperiores eveniet facere assumenda aspernatur rerum ratione ex quidem eos ipsam officia sint labore enim ipsa, aperiam quos!</p>
 
  </div>

  <div class="tab-pane fade" id="review-tab-pane" role="tabpanel" aria-labelledby="review-tab" tabindex="0">
  <h3 class="pt-20">REVIEWS</h3>
  <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Illum voluptatem tempora, ad, voluptate ab culpa dolore natus nam repellendus quis dolorum. Tempora asperiores eveniet facere assumenda aspernatur rerum ratione ex quidem eos ipsam officia sint labore enim ipsa, aperiam quos!</p>
 
  </div>
</div>



        </div>


        <div class="col-lg-4  col-md-4 detail-inst mt-20 mb-20">
            <h3>Featured Instructor</h3>
            <div class="detail-inst-info">
            <img src="assets/images/course/ins1.webp" alt="" class="img">
            <div class="icon10">
            <span>John Elvis</span>
            <br>
            <i class="fab fa-facebook"></i>
            <i class="fab fa-instagram"></i>
            <i class="fab fa-youtube"></i>
            <i class="fab fa-tiktok"></i>

            </div>
            </div>
        </div>
    </div>
</div>
<!-- second list of details ends here -->




<?php include 'footer.php';?>