<?php include 'header.php';?>


<!-- BANNER WORKS STARTS HERE -->
<div class="container-fluid about-banner">
    <div class="row">
        <div class="col-lg-2">

        </div>

        <div class="col-lg-8" data-aos="fade-down"
     data-aos-easing="linear"
     data-aos-duration="1000">
        <h2>EVENTS</h2>

        <p>"At Parents2Teacher, join us for exciting events! We're dedicated to empowering student success with innovative programs and personalized support. Dive into engaging experiences designed for everyone."</p>
        </div>

        <div class="col-lg-2">
            
        </div>
    </div>
     </div>

<!-- BANNER WORKS ENDS HERE -->


<!-- EVENTS SECTIONS STARTS HERE  -->
<section class="events">
 <div class="container" data-aos="fade-right"  data-aos-duration="1000">
    <img src="./assets/images/events/event.webp" alt="">  
    <h3 class="pt-50">Introduction To Events</h3>
    <p>Welcome to our Parents2Teacher events! Join us as we delve into the dynamic relationship between parents and teachers. Through engaging discussions and insightful sessions, we aim to foster collaboration and understanding to better support student success. Let's come together to explore how we can empower our students through effective partnership between parents and teachers.</p>
    <p class="blackquotes" data-aos="fade-right"  data-aos-duration="2000">"Come to our special Parents2Teacher events where we talk about how parents and teachers can work together better. Let's find new ideas and ways to help students do their best in school and beyond."</p> 
    <p>Explore with us at our Parents2Teacher gatherings, where we discuss how parents and teachers can support each other in helping students thrive. Let's share stories and strategies to make learning a positive experience for all.</p> 
     <p>Join our friendly community at Parents2Teacher events, where we focus on building strong partnerships between parents and teachers. Together, we'll explore practical ideas and build connections to ensure every student receives the guidance they need to succeed.</p>
      <div class="icon text-center pt-20 pb-20"  data-aos="fade-down"
     data-aos-easing="linear"
     data-aos-duration="2000">
    <i class="fab fa-facebook"></i>
    <i class="fab fa-instagram"></i>
    <i class="fab fa-youtube"></i>
    <i class="fab fa-tiktok"></i>
      </div>
    <h3>Mention Your Thoughts</h3>

    <div class="mb-3">
  <textarea class="form-control" id="exampleFormControlTextarea1" rows="10" placeholder="Message"></textarea>
</div>
     
    </div>
</section>



<!-- EVENTS SECTIONS ENDS HERE  -->



        <!-- course end -->
        <?php include 'footer.php';?>